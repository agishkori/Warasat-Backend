# وراثت کیلکولیٹر — Warasat Calculator (Python / Flask)

Warasat_v_3.9.xlsm کی "Wrasat" شیٹ کا حساب Python میں: فقہ حنفی، فقہ جعفریہ، مسلم فیملی لاء آرڈیننس 1961 / اسلامی قانون، عول و رد، اور کنال/مرلہ/فٹ (یا سرسائی/گز) میں رقبہ اور رقم کی تقسیم۔

ساتھ میں: اکاؤنٹ، 30 دن مفت، پھر 50 روپے ماہانہ یا 500 روپے سالانہ (Google Play Billing، خودکار تصدیق)، ایڈمن پینل، اور موبائل ایپ کے لیے JSON API۔

## فائلیں

| فائل | کام |
|---|---|
| `warasat/engine.py` | وراثت کا پورا حساب (Excel شیٹ والی منطق) |
| `warasat/play.py` | Google Play خریداری کی تصدیق |
| `static/billing.js` | ایپ کے اندر خریداری (Digital Goods API) |
| `app.py` | ویب سائٹ + API + ایڈمن پینل |
| `config.py` | قیمت، مفت دن، JazzCash/EasyPaisa نمبر |
| `templates/`, `static/` | اردو موبائل فرینڈلی صفحات |
| `tests/` | ٹیسٹ (`python -m pytest`) |
| `pythonanywhere_wsgi.py` | PythonAnywhere کی WSGI فائل کا نمونہ |

## اپنے کمپیوٹر پر چلائیں

```bash
pip install -r requirements.txt
python app.py        # پھر براؤزر میں http://127.0.0.1:5000
```

03007283456 سے رجسٹر کریں تو وہ اکاؤنٹ خود بخود **ایڈمن** بن جاتا ہے (config.py میں `ADMIN_PHONES`)۔

## 1) GitHub پر اپلوڈ

1. github.com پر نیا repository بنائیں، مثلاً `warasat-app` (Private بہتر ہے)۔
2. اس فولڈر میں:
```bash
git init
git add .
git commit -m "Warasat calculator"
git branch -M main
git remote add origin https://github.com/YOURNAME/warasat-app.git
git push -u origin main
```
(یا GitHub ویب سائٹ پر "Add file → Upload files" سے یہ سب فائلیں ڈال دیں۔)

## 2) PythonAnywhere پر چلائیں

1. pythonanywhere.com پر اکاؤنٹ بنائیں۔
2. **Consoles → Bash** کھولیں:
```bash
git clone https://github.com/YOURNAME/warasat-app.git
cd warasat-app
pip3 install --user -r requirements.txt
```
(Private repo ہو تو GitHub پر Personal Access Token بنا کر پاس ورڈ کی جگہ استعمال کریں۔)
3. **Web → Add a new web app → Manual configuration → Python 3.x**۔
4. اسی صفحہ پر "WSGI configuration file" کھولیں، سب مٹا کر `pythonanywhere_wsgi.py` کا متن ڈالیں، `YOURUSERNAME` اور `SECRET_KEY` بدلیں۔
5. **Static files**: URL `/static/` → Directory `/home/YOURUSERNAME/warasat-app/static`
6. **Force HTTPS** آن کریں، پھر **Reload** دبائیں۔
7. `https://YOURUSERNAME.pythonanywhere.com` کھولیں، 03007283456 سے رجسٹر کریں — آپ ایڈمن ہیں۔

نئی تبدیلی کے بعد: Bash میں `cd warasat-app && git pull` پھر Web tab میں Reload۔
ڈیٹا `warasat.db` (SQLite) میں ہے — وقتاً فوقتاً Files tab سے ڈاؤن لوڈ کر کے بیک اپ رکھیں۔

نوٹ: PythonAnywhere کا مفت اکاؤنٹ ہر 3 ماہ بعد ایک بٹن دبا کر بڑھانا پڑتا ہے اور اپنا ڈومین نہیں ملتا؛ ایپ عام ہونے پر $5 والا پلان بہتر رہے گا۔

## ادائیگی: Google Play Billing (خودکار)

- **پلان:** ماہانہ 50 روپے، سالانہ 500 روپے۔ رجسٹریشن پر 30 دن مفت (یہ سرور دیتا ہے، کارڈ کی ضرورت نہیں)۔
- صارف Play Store والی ایپ میں "خریدیں" دباتا ہے → Google ادائیگی لیتا ہے → ایپ purchase token سرور کو بھیجتی ہے → سرور Google سے تصدیق کر کے اکاؤنٹ **خود بخود** فعال کر دیتا ہے اور خریداری acknowledge کرتا ہے۔ ایڈمن کو کچھ منظور نہیں کرنا پڑتا۔
- ہر مہینے/سال کی تجدید، منسوخی، ریفنڈ کی اطلاع Google خود سرور کو بھیجتا ہے (`/api/play/rtdn`) اور اکاؤنٹ اسی حساب سے بڑھتا/بند ہوتا ہے۔
- ماہانہ سے سالانہ پر جانے پر پرانی خریداری خود "تبدیل شدہ" ہو جاتی ہے۔
- ایک خریداری ایک ہی اکاؤنٹ سے جڑ سکتی ہے (دوسرے نمبر پر استعمال نہیں ہو سکتی)۔
- JazzCash/EasyPaisa والا دستی طریقہ کوڈ میں موجود ہے مگر **بند** ہے (`ENABLE_MANUAL_PAYMENTS=0`)، کیونکہ Play Store ایپ میں صرف Google Play Billing کی اجازت ہے۔
- Google ہر ادائیگی سے اپنی فیس کاٹ کر باقی رقم آپ کے بینک اکاؤنٹ میں بھیجتا ہے (Play Console › Payments profile میں بینک اکاؤنٹ لگائیں)۔

### ایک بار کی سیٹنگ (ترتیب سے)

**A. Play Console** (play.google.com/console — ایک بار 25 ڈالر فیس)
1. نئی ایپ بنائیں۔ package name وہی رکھیں جو `PLAY_PACKAGE_NAME` میں ہے (پہلے سے `com.warasat.calculator`)۔
2. Setup › Payments profile: مرچنٹ اکاؤنٹ اور بینک اکاؤنٹ بنائیں۔
3. Android ایپ (نیچے حصہ C) کا پہلا ورژن Internal testing پر اپلوڈ کریں — اس کے بغیر سبسکرپشن نہیں بنتی۔
4. Monetize › Products › **Subscriptions**: دو سبسکرپشن بنائیں:
   - Product ID `warasat_monthly` → base plan: Auto-renewing، Billing period **1 month**، قیمت **PKR 50**
   - Product ID `warasat_yearly` → base plan: Auto-renewing، Billing period **1 year**، قیمت **PKR 500**
   (Play پر مفت trial **نہ** لگائیں — مفت مہینہ سرور پہلے ہی دے رہا ہے۔)
5. Setup › License testing میں اپنا Gmail ڈالیں تاکہ آپ بغیر پیسوں کے ٹیسٹ خریداری کر سکیں۔

**B. Google Cloud** (console.cloud.google.com)
1. نیا پروجیکٹ بنائیں، "Google Play Android Developer API" Enable کریں۔
2. IAM › Service accounts › نیا service account بنائیں › Keys › Add key › JSON — فائل ڈاؤن لوڈ ہو گی۔
3. Play Console › Users and permissions › Invite new user: service account کا email ڈالیں، "View financial data" اور "Manage orders and subscriptions" کی اجازت دیں۔
4. JSON فائل کو PythonAnywhere پر `warasat-app/play-service-account.json` کے نام سے اپلوڈ کریں (GitHub پر **ہرگز نہیں** — `.gitignore` میں پہلے سے شامل ہے)۔
5. Pub/Sub › Topics › نیا topic `play-rtdn`۔ اس topic کی Permissions میں `google-play-developer-notifications@system.gserviceaccount.com` کو **Pub/Sub Publisher** دیں۔
6. اس topic پر Subscription بنائیں: Delivery type **Push**، Endpoint:
   `https://YOURUSERNAME.pythonanywhere.com/api/play/rtdn?secret=اپنا-خفیہ-لفظ`
7. Play Console › Monetize › Monetization setup › Real-time developer notifications: topic کا پورا نام (`projects/PROJECT_ID/topics/play-rtdn`) ڈالیں، "Send test notification" دبائیں۔

**C. Android ایپ (TWA)**
1. سائٹ HTTPS پر چل رہی ہو (PythonAnywhere پر ہوتی ہے)۔
2. pwabuilder.com پر اپنی سائٹ کا URL ڈالیں › Android › package name `com.warasat.calculator` › **"Enable Play Billing"** آن کریں (یا Bubblewrap میں `playBilling` فیچر)۔ .aab فائل بن جائے گی۔
3. Play Console › Setup › App signing سے **SHA-256 fingerprint** کاپی کر کے WSGI فائل میں `ASSETLINKS_SHA256` میں ڈالیں — اس سے ایپ میں براؤزر کی پٹی نظر نہیں آتی اور Billing چلتی ہے (`/.well-known/assetlinks.json` خود بنتا ہے)۔

**D. PythonAnywhere WSGI فائل** — `pythonanywhere_wsgi.py` دیکھیں: `PLAY_PACKAGE_NAME`، `RTDN_SECRET`، `ASSETLINKS_SHA256` بھریں، پھر Reload۔

**اہم — PythonAnywhere مفت اکاؤنٹ:** مفت اکاؤنٹ سے باہر کی ویب سائٹس تک رسائی صرف ان کی allowlist پر ہوتی ہے۔ Bash console میں یہ چلا کر دیکھیں:
`python3 -c "import requests; print(requests.get('https://androidpublisher.googleapis.com').status_code)"`
اگر `403 Forbidden / Tunnel connection failed` آئے تو یا تو PythonAnywhere سے allowlist میں شامل کرنے کی درخواست کریں، یا $5 والا Hacker پلان لیں (اس میں پابندی نہیں، اور اپنی ڈومین بھی لگتی ہے)۔ پیسے لینے والی ایپ کے لیے Hacker پلان ہی بہتر ہے۔

### ایڈمن پینل (`/admin`)
- کل صارفین، مفت عرصہ، فعال ماہانہ/سالانہ سبسکرائبرز، ختم شدہ
- Google Play کی تمام خریداریاں (حیثیت، ختم ہونے کی تاریخ، آرڈر نمبر) + "تازہ کریں"
- کسی بھی صارف کو 1/3/6 مہینے یا 1 سال مفت دینا، اکاؤنٹ بند کرنا، نیا پاس ورڈ

### صارف کا صفحہ (`/subscribe`)
- ماہانہ / سالانہ پلان (قیمت Google Play سے مقامی کرنسی میں آتی ہے)، "خریدیں"
- "پرانی خریداری بحال کریں" (نیا فون / دوبارہ انسٹال)
- Google Play پر سبسکرپشن منسوخ کرنے کا لنک، اپنی خریداریوں کی فہرست

## موبائل ایپ کے لیے API

سب درخواستوں میں `Authorization: Bearer <token>` (رجسٹر/لاگ ان کے علاوہ)۔

| Method | URL | Body / نتیجہ |
|---|---|---|
| GET | `/api/config` | قیمت، مفت دن، ادائیگی نمبر، ورثاء کی فہرست |
| POST | `/api/register` | `{name, phone, password, device_id}` → `{token, user}` |
| POST | `/api/login` | `{phone, password}` → `{token, user}` |
| GET | `/api/me` | صارف + سبسکرپشن (`active`, `days_left`) |
| POST | `/api/calculate` | نیچے دیکھیں؛ سبسکرپشن ختم ہو تو 402 |
| GET | `/api/history` | محفوظ حسابات |
| GET | `/api/plans` | ماہانہ/سالانہ پلان، product IDs |
| POST | `/api/play/verify` | `{purchase_token}` یا `{purchase_tokens:[...]}` → Google سے تصدیق، اکاؤنٹ فعال |
| POST | `/api/play/rtdn?secret=…` | Google Pub/Sub کی اطلاعات (خودکار) |

`/api/calculate` کی مثال:
```json
{
  "fiqh": "hanafi",
  "law": "mflo",
  "heirs": {"wife": 1, "son": 3, "daughter": 4},
  "predeceased_sons": [{"sons": 1, "daughters": 2}],
  "predeceased_daughters": [],
  "area": {"kanal": 2, "marla": 0, "sub": 0, "unit": "foot"},
  "amount": 800000
}
```
ورثاء کی keys: `husband, wife, mother, pat_grandmother (دادی), mat_grandmother (نانی), father, grandfather (دادا), son, daughter, full_brother, full_sister, uterine (مادری بہن بھائی), son_son (پوتا), son_daughter (پوتی), sss (پڑپوتا), ssd (پڑپوتی), pat_brother, pat_sister`

## Excel شیٹ سے موازنہ

انجن کو اصل شیٹ کے ساتھ 94 مختلف کیسز پر چلایا گیا (شیٹ LibreOffice میں دوبارہ calculate کر کے)۔ عام کیسز (بیوہ/بیٹے/بیٹیاں، عمریتین، عول، رد، فوت شدہ اولاد، فقہ جعفریہ کے بنیادی کیس) بالکل ایک جیسے آئے۔ جہاں فرق آیا وہاں شیٹ میں غلطی تھی — مثلاً کئی کیسز میں شیٹ کے حصوں کا مجموعہ 1 سے زیادہ بن جاتا ہے (دادا + پوتے، پڑپوتی، دادا + پدری بھائی، فقہ جعفریہ میں پوتی وغیرہ)۔ ایپ ہمیشہ پورا ترکہ تقسیم کرتی ہے (ٹیسٹ میں 12,000 بے ترتیب کیسز سے جانچا گیا)۔

دو جگہ ایپ کا فیصلہ شیٹ سے جان بوجھ کر مختلف ہے:
- اکیلا شوہر (کوئی اور وارث نہ ہو): شیٹ 1/2 دیتی ہے، ایپ بقیہ بھی رد کر کے پورا دیتی ہے (جیسے شیٹ اکیلی بیوہ کو دیتی ہے)۔
- فقہ جعفریہ میں دادی + نانی: نانی کو 1/3، شیٹ 1/6 دیتی ہے۔

اگر آپ کسی کیس میں شیٹ والا جواب چاہتے ہیں تو بتائیں، انجن بدلا جا سکتا ہے۔

## ٹیسٹ

`pip install pytest && python -m pytest` — 25 ٹیسٹ، جن میں Google کی جعلی (fake) سروس سے پوری خریداری، تجدید، اپگریڈ، منسوخی، ریفنڈ اور ایک ٹوکن دو اکاؤنٹس پر استعمال کی کوشش جانچی گئی ہے۔ اصل Google سے ٹیسٹ Play Console کے License testing اکاؤنٹ سے کریں۔
