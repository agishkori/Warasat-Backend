"""
Warasat Calculator — Flask backend + mobile-friendly Urdu web app.

Run locally:   python app.py          (http://127.0.0.1:5000)
PythonAnywhere: see README.md (WSGI file imports `app` from here)
"""
import hashlib
import json
import re
import secrets
from datetime import timedelta
from functools import wraps

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import config
from warasat import engine, play
from warasat.db import (extend_subscription, get_db, init_db, now, parse,
                        subscription, ts)

app = Flask(__name__)
app.config.from_object(config)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(days=60),
                  JSON_AS_ASCII=False)
app.json.ensure_ascii = False
init_db(app)

PHONE_RE = re.compile(r"^03\d{9}$")
MAX_LINES = 3   # predeceased sons / daughters shown on the form


# =========================================================== helpers
def norm_phone(p):
    p = re.sub(r"[\s\-]", "", p or "")
    if p.startswith("+92"):
        p = "0" + p[3:]
    elif p.startswith("92") and len(p) == 12:
        p = "0" + p[2:]
    return p


def hash_token(t):
    return hashlib.sha256(t.encode()).hexdigest()


def create_user(name, phone, password, device_id=None):
    db = get_db()
    n = now()
    trial_ends = n + timedelta(days=config.TRIAL_DAYS)
    # one free trial per device
    if device_id and db.execute("SELECT 1 FROM users WHERE device_id=?", (device_id,)).fetchone():
        trial_ends = n
    is_admin = 1 if phone in config.ADMIN_PHONES else 0
    cur = db.execute(
        "INSERT INTO users(name, phone, password_hash, created_at, trial_ends, is_admin, device_id) "
        "VALUES (?,?,?,?,?,?,?)",
        (name, phone, generate_password_hash(password), ts(n), ts(trial_ends), is_admin, device_id))
    db.commit()
    return db.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()


def validate_register(name, phone, password):
    if not name or len(name) > 80:
        return "نام درج کریں"
    if not PHONE_RE.match(phone):
        return "موبائل نمبر 03XXXXXXXXX کی شکل میں لکھیں"
    if len(password) < 6:
        return "پاس ورڈ کم از کم 6 حروف کا ہو"
    if get_db().execute("SELECT 1 FROM users WHERE phone=?", (phone,)).fetchone():
        return "یہ نمبر پہلے سے رجسٹرڈ ہے، لاگ ان کریں"
    return None


def user_by_phone(phone):
    return get_db().execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()


def load_user():
    if "user" in g:
        return g.user
    g.user = None
    auth = request.headers.get("Authorization", "")
    db = get_db()
    if auth.startswith("Bearer "):
        row = db.execute("SELECT u.* FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?",
                         (hash_token(auth[7:].strip()),)).fetchone()
        g.user = row
    elif session.get("uid"):
        g.user = db.execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
    if g.user is not None and g.user["is_blocked"]:
        g.user = None
    return g.user


@app.context_processor
def inject():
    u = load_user()
    return {"me": u, "sub": subscription(u) if u else None, "cfg": config, "PLANS": config.PLANS,
            "csrf_token": csrf_token, "HEIRS": engine.HEIRS}


# ---- CSRF for web forms
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


@app.before_request
def csrf_protect():
    if request.method != "POST":
        return
    expected = session.get("_csrf")
    if not request.path.startswith("/api/"):
        if not expected or not secrets.compare_digest(request.form.get("_csrf", ""), expected):
            abort(400, "CSRF token missing")
    elif (session.get("uid") and not request.headers.get("Authorization", "").startswith("Bearer ")
          and (not expected or not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), expected))):
        # page JavaScript calling the API with the login cookie must send the token
        return jsonify(error="CSRF token missing"), 400


def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not load_user():
            if request.path.startswith("/api/"):
                return jsonify(error="login required", error_ur="لاگ ان کریں"), 401
            return redirect(url_for("login", next=request.path))
        return f(*a, **kw)
    return wrapper


def admin_required(f):
    @wraps(f)
    @login_required
    def wrapper(*a, **kw):
        if not g.user["is_admin"]:
            abort(403)
        return f(*a, **kw)
    return wrapper


def subscription_required(f):
    @wraps(f)
    @login_required
    def wrapper(*a, **kw):
        if not subscription(g.user)["active"]:
            if request.path.startswith("/api/"):
                return jsonify(error="subscription expired", error_ur="آپ کی سبسکرپشن ختم ہو چکی ہے",
                               subscription=subscription(g.user)), 402
            flash("آپ کا فری/ادا شدہ عرصہ ختم ہو چکا ہے۔ براہِ کرم ادائیگی کریں۔", "error")
            return redirect(url_for("subscribe"))
        return f(*a, **kw)
    return wrapper


def submit_payment(user, method, txn_id, sender, months):
    if not config.ENABLE_MANUAL_PAYMENTS:
        return None, "ادائیگی صرف Google Play کے ذریعے ہوتی ہے"
    method = (method or "").lower()
    txn_id = re.sub(r"\s", "", txn_id or "")
    sender = norm_phone(sender)
    try:
        months = int(months or 1)
    except ValueError:
        months = 0
    if method not in [a["method"] for a in config.PAYMENT_ACCOUNTS]:
        return None, "ادائیگی کا طریقہ منتخب کریں"
    if not re.match(r"^[A-Za-z0-9]{6,30}$", txn_id):
        return None, "درست ٹرانزیکشن آئی ڈی (TID) لکھیں"
    if sender and not PHONE_RE.match(sender):
        return None, "بھیجنے والا نمبر درست نہیں"
    if months < 1 or months > 12:
        return None, "مہینے 1 سے 12 تک"
    db = get_db()
    if db.execute("SELECT 1 FROM payments WHERE txn_id=?", (txn_id,)).fetchone():
        return None, "یہ ٹرانزیکشن آئی ڈی پہلے ہی جمع ہو چکی ہے"
    if db.execute("SELECT COUNT(*) FROM payments WHERE user_id=? AND status='pending'",
                  (user["id"],)).fetchone()[0] >= 3:
        return None, "آپ کی پچھلی ادائیگیاں ابھی زیرِ غور ہیں"
    db.execute("INSERT INTO payments(user_id, method, txn_id, sender_number, amount, months, created_at) "
               "VALUES (?,?,?,?,?,?,?)",
               (user["id"], method, txn_id, sender, months * config.MONTHLY_PRICE, months, ts(now())))
    db.commit()
    return True, None


def payload_from_form(form):
    heirs = {}
    for key in engine.HEIR_INFO:
        v = form.get("h_" + key, "").strip()
        if v and v != "0":
            heirs[key] = v
    ps, pd = [], []
    for i in range(1, MAX_LINES + 1):
        for prefix, lst in (("ps", ps), ("pd", pd)):
            s = form.get(f"{prefix}{i}_sons", "").strip()
            d = form.get(f"{prefix}{i}_daughters", "").strip()
            if (s and s != "0") or (d and d != "0"):
                lst.append({"sons": s or 0, "daughters": d or 0})
    return {
        "fiqh": form.get("fiqh", "hanafi"),
        "law": form.get("law", "mflo"),
        "heirs": heirs,
        "predeceased_sons": ps,
        "predeceased_daughters": pd,
        "area": {"kanal": form.get("kanal") or 0, "marla": form.get("marla") or 0,
                 "sub": form.get("sub") or 0, "unit": form.get("unit", "foot")},
        "amount": form.get("amount") or None,
        "title": (form.get("title") or "").strip()[:100],
    }


def save_calc(user, payload):
    db = get_db()
    db.execute("INSERT INTO calculations(user_id, title, input_json, created_at) VALUES (?,?,?,?)",
               (user["id"], payload.get("title") or None, json.dumps(payload, ensure_ascii=False), ts(now())))
    db.commit()


# =========================================================== Google Play billing
def plan_for_product(product_id):
    for key, p in config.PLANS.items():
        if p["product_id"] == product_id:
            return key
    return None


def recompute_play_until(db, user_id):
    states = tuple(play.ENTITLED_STATES)
    row = db.execute(f"SELECT MAX(expiry) FROM play_purchases WHERE user_id=? AND state IN ({','.join('?' * len(states))})",
                     (user_id, *states)).fetchone()
    db.execute("UPDATE users SET play_until=? WHERE id=?", (row[0], user_id))


def apply_play_purchase(token, user_id=None):
    """Ask Google about `token`, store it, acknowledge it, update the owner's access.
    user_id=None is used by the webhook (owner taken from what we stored before)."""
    token = (token or "").strip()
    if not token or len(token) > 2000:
        raise play.PlayError("purchase token missing")
    info = play.parse_subscription(play.get_client().get_subscription(token))
    plan = plan_for_product(info["product_id"])
    if not plan:
        raise play.PlayError(f"unknown product {info['product_id']}")

    db = get_db()
    existing = db.execute("SELECT * FROM play_purchases WHERE purchase_token=?", (token,)).fetchone()
    owner = existing["user_id"] if existing and existing["user_id"] else None
    linked = None
    if info["linked_token"]:
        linked = db.execute("SELECT * FROM play_purchases WHERE purchase_token=?", (info["linked_token"],)).fetchone()
        if owner is None and linked is not None:
            owner = linked["user_id"]
    if user_id is not None:
        if owner and owner != user_id:
            raise play.PlayError("یہ خریداری کسی دوسرے اکاؤنٹ سے منسلک ہے")
        owner = user_id

    acknowledged = info["acknowledged"]
    if not acknowledged and info["state"] in ("SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"):
        play.get_client().acknowledge(info["product_id"], token)
        acknowledged = True

    n = ts(now())
    db.execute("""INSERT INTO play_purchases(purchase_token, user_id, product_id, plan, state, expiry, auto_renewing,
                    acknowledged, order_id, linked_token, is_test, raw, created_at, updated_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(purchase_token) DO UPDATE SET user_id=excluded.user_id, product_id=excluded.product_id,
                    plan=excluded.plan, state=excluded.state, expiry=excluded.expiry,
                    auto_renewing=excluded.auto_renewing, acknowledged=excluded.acknowledged,
                    order_id=excluded.order_id, linked_token=excluded.linked_token, is_test=excluded.is_test,
                    raw=excluded.raw, updated_at=excluded.updated_at""",
               (token, owner, info["product_id"], plan, info["state"], ts(info["expiry"]), int(info["auto_renewing"]),
                int(acknowledged), info["order_id"], info["linked_token"], int(info["test"]), info["raw"], n, n))
    if linked is not None:
        # upgrade (monthly -> yearly) or re-subscribe: old token no longer gives access
        db.execute("UPDATE play_purchases SET state='REPLACED', updated_at=? WHERE purchase_token=?",
                   (n, info["linked_token"]))
        if linked["user_id"] and linked["user_id"] != owner:
            recompute_play_until(db, linked["user_id"])
    if owner:
        recompute_play_until(db, owner)
    db.commit()
    return info, plan, owner


def play_purchases_of(user_id):
    return get_db().execute("SELECT * FROM play_purchases WHERE user_id=? ORDER BY updated_at DESC LIMIT 20",
                            (user_id,)).fetchall()


# =========================================================== web pages
@app.route("/")
def index():
    return redirect(url_for("calc" if load_user() else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = norm_phone(request.form.get("phone"))
        pw = request.form.get("password", "")
        err = validate_register(name, phone, pw)
        if err:
            flash(err, "error")
        else:
            u = create_user(name, phone, pw)
            session.clear()
            session.permanent = True
            session["uid"] = u["id"]
            flash(f"خوش آمدید! آپ کو {config.TRIAL_DAYS} دن مفت استعمال کی سہولت دی گئی ہے۔", "ok")
            return redirect(url_for("calc"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = user_by_phone(norm_phone(request.form.get("phone")))
        if u and check_password_hash(u["password_hash"], request.form.get("password", "")):
            if u["is_blocked"]:
                flash("یہ اکاؤنٹ بند ہے", "error")
            else:
                session.clear()
                session.permanent = True
                session["uid"] = u["id"]
                nxt = request.args.get("next") or ""
                return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("calc"))
        else:
            flash("نمبر یا پاس ورڈ غلط ہے", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/calc", methods=["GET", "POST"])
@subscription_required
def calc():
    report, payload, error = None, None, None
    if request.method == "POST":
        payload = payload_from_form(request.form)
        try:
            report = engine.run(payload)
            save_calc(g.user, payload)
        except engine.InputError as e:
            error = str(e)
    elif request.args.get("h"):
        row = get_db().execute("SELECT * FROM calculations WHERE id=? AND user_id=?",
                               (request.args["h"], g.user["id"])).fetchone()
        if row:
            payload = json.loads(row["input_json"])
            try:
                report = engine.run(payload)
            except engine.InputError as e:
                error = str(e)
    return render_template("calc.html", report=report, p=payload or {}, error=error, max_lines=MAX_LINES)


@app.route("/history")
@login_required
def history():
    rows = get_db().execute("SELECT * FROM calculations WHERE user_id=? ORDER BY id DESC LIMIT 100",
                            (g.user["id"],)).fetchall()
    items = []
    for r in rows:
        p = json.loads(r["input_json"])
        summary = "، ".join(f"{engine.HEIR_INFO[k]['ur']} {v}" for k, v in p.get("heirs", {}).items())
        items.append({"id": r["id"], "title": r["title"], "created_at": r["created_at"], "summary": summary})
    return render_template("history.html", items=items)


@app.route("/subscribe", methods=["GET", "POST"])
@login_required
def subscribe():
    if request.method == "POST":
        ok, err = submit_payment(g.user, request.form.get("method"), request.form.get("txn_id"),
                                 request.form.get("sender"), request.form.get("months"))
        if ok:
            flash("آپ کی ادائیگی موصول ہو گئی ہے۔ تصدیق کے بعد آپ کا اکاؤنٹ فعال ہو جائے گا۔", "ok")
            return redirect(url_for("subscribe"))
        flash(err, "error")
    pays = get_db().execute("SELECT * FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 20",
                            (g.user["id"],)).fetchall()
    return render_template("subscribe.html", payments=pays, purchases=play_purchases_of(g.user["id"]),
                           STATE_UR=play.STATE_UR)


@app.route("/privacy")
def privacy():
    return render_template("privacy.html")


# ----------------------------------------------------------- admin
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    status = request.args.get("status", "pending")
    pays = db.execute("SELECT p.*, u.name, u.phone FROM payments p JOIN users u ON u.id=p.user_id "
                      "WHERE p.status=? ORDER BY p.id DESC LIMIT 200", (status,)).fetchall()
    q = request.args.get("q", "").strip()
    if q:
        users = db.execute("SELECT * FROM users WHERE phone LIKE ? OR name LIKE ? ORDER BY id DESC LIMIT 100",
                           (f"%{q}%", f"%{q}%")).fetchall()
    else:
        users = db.execute("SELECT * FROM users ORDER BY id DESC LIMIT 50").fetchall()
    n = ts(now())
    ent = tuple(play.ENTITLED_STATES)
    ph = ",".join("?" * len(ent))
    active_by_plan = {k: db.execute(f"SELECT COUNT(DISTINCT user_id) FROM play_purchases WHERE plan=? AND state IN ({ph}) "
                                    "AND expiry>? AND is_test=0", (k, *ent, n)).fetchone()[0] for k in config.PLANS}
    stats = {
        "users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "trial": db.execute("SELECT COUNT(*) FROM users WHERE trial_ends>? AND (paid_until IS NULL OR paid_until<?) "
                            "AND (play_until IS NULL OR play_until<?) AND is_admin=0", (n, n, n)).fetchone()[0],
        "monthly": active_by_plan.get("monthly", 0),
        "yearly": active_by_plan.get("yearly", 0),
        "expired": db.execute("SELECT COUNT(*) FROM users WHERE trial_ends<? AND (paid_until IS NULL OR paid_until<?) "
                              "AND (play_until IS NULL OR play_until<?) AND is_admin=0", (n, n, n)).fetchone()[0],
        "pending": db.execute("SELECT COUNT(*) FROM payments WHERE status='pending'").fetchone()[0],
    }
    stats["monthly_value"] = stats["monthly"] * config.PLANS["monthly"]["price"]
    stats["yearly_value"] = stats["yearly"] * config.PLANS["yearly"]["price"]
    pf = request.args.get("pf", "all")
    where = {"active": f"WHERE p.state IN ({ph}) AND p.expiry>?", "ended": f"WHERE p.state NOT IN ({ph})"}.get(pf, "")
    params = {"active": (*ent, n), "ended": ent}.get(pf, ())
    purchases = db.execute("SELECT p.*, u.name, u.phone FROM play_purchases p LEFT JOIN users u ON u.id=p.user_id "
                           f"{where} ORDER BY p.updated_at DESC LIMIT 200", params).fetchall()
    return render_template("admin.html", pays=pays, users=users, status=status, q=q, stats=stats,
                           subscription=subscription, purchases=purchases, pf=pf, STATE_UR=play.STATE_UR)


@app.route("/admin/play/refresh", methods=["POST"])
@admin_required
def admin_play_refresh():
    try:
        apply_play_purchase(request.form.get("token"))
        flash("Google سے تازہ حیثیت لے لی گئی", "ok")
    except play.PlayError as e:
        flash(f"Google: {e}", "error")
    return redirect(url_for("admin", pf=request.form.get("pf", "all")))


@app.route("/admin/payment/<int:pid>", methods=["POST"])
@admin_required
def admin_payment(pid):
    db = get_db()
    p = db.execute("SELECT * FROM payments WHERE id=?", (pid,)).fetchone()
    if not p or p["status"] != "pending":
        flash("یہ ادائیگی پہلے ہی نمٹائی جا چکی ہے", "error")
        return redirect(url_for("admin"))
    action = request.form.get("action")
    if action == "approve":
        until = extend_subscription(db, p["user_id"], p["months"] * config.DAYS_PER_MONTH)
        db.execute("UPDATE payments SET status='approved', reviewed_at=? WHERE id=?", (ts(now()), pid))
        flash(f"منظور — اکاؤنٹ {ts(until)[:10]} تک فعال", "ok")
    elif action == "reject":
        db.execute("UPDATE payments SET status='rejected', note=?, reviewed_at=? WHERE id=?",
                   (request.form.get("note", "")[:200], ts(now()), pid))
        flash("مسترد کر دی گئی", "ok")
    db.commit()
    return redirect(url_for("admin"))


@app.route("/admin/user/<int:uid>", methods=["POST"])
@admin_required
def admin_user(uid):
    db = get_db()
    action = request.form.get("action")
    if action == "extend":
        try:
            days = max(1, min(730, int(request.form.get("days", 30))))
        except ValueError:
            days = 30
        until = extend_subscription(db, uid, days)
        flash(f"اکاؤنٹ {ts(until)[:10]} تک بڑھا دیا گیا", "ok")
    elif action == "block":
        db.execute("UPDATE users SET is_blocked=1 - is_blocked WHERE id=? AND is_admin=0", (uid,))
        db.execute("DELETE FROM tokens WHERE user_id=?", (uid,))
    elif action == "reset_password":
        newpw = secrets.token_hex(3)
        db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(newpw), uid))
        db.execute("DELETE FROM tokens WHERE user_id=?", (uid,))
        flash(f"نیا پاس ورڈ: {newpw}", "ok")
    db.commit()
    return redirect(url_for("admin", q=request.form.get("q", "")))


# =========================================================== JSON API (mobile app)
def api_user_json(u):
    return {"id": u["id"], "name": u["name"], "phone": u["phone"], "is_admin": bool(u["is_admin"]),
            "subscription": subscription(u)}


def issue_token(u):
    t = secrets.token_urlsafe(32)
    db = get_db()
    db.execute("INSERT INTO tokens(token_hash, user_id, created_at) VALUES (?,?,?)",
               (hash_token(t), u["id"], ts(now())))
    db.commit()
    return t


@app.route("/api/health")
def api_health():
    return jsonify(ok=True, app=config.APP_NAME)


@app.route("/api/config")
def api_config():
    return jsonify(trial_days=config.TRIAL_DAYS, monthly_price=config.MONTHLY_PRICE,
                   payment_accounts=config.PAYMENT_ACCOUNTS, account_title=config.ACCOUNT_TITLE,
                   heirs=[{"key": h[0], "ur": h[1], "en": h[2]} for h in engine.HEIRS],
                   units=list(engine.UNITS_PER_MARLA))


@app.route("/api/register", methods=["POST"])
def api_register():
    d = request.get_json(silent=True) or {}
    name, phone, pw = (d.get("name") or "").strip(), norm_phone(d.get("phone")), d.get("password") or ""
    err = validate_register(name, phone, pw)
    if err:
        return jsonify(error=err), 400
    u = create_user(name, phone, pw, (d.get("device_id") or "")[:100] or None)
    return jsonify(token=issue_token(u), user=api_user_json(u))


@app.route("/api/login", methods=["POST"])
def api_login():
    d = request.get_json(silent=True) or {}
    u = user_by_phone(norm_phone(d.get("phone")))
    if not u or not check_password_hash(u["password_hash"], d.get("password") or ""):
        return jsonify(error="نمبر یا پاس ورڈ غلط ہے"), 401
    if u["is_blocked"]:
        return jsonify(error="یہ اکاؤنٹ بند ہے"), 403
    return jsonify(token=issue_token(u), user=api_user_json(u))


@app.route("/api/logout", methods=["POST"])
@login_required
def api_logout():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        db = get_db()
        db.execute("DELETE FROM tokens WHERE token_hash=?", (hash_token(auth[7:].strip()),))
        db.commit()
    return jsonify(ok=True)


@app.route("/api/me")
@login_required
def api_me():
    return jsonify(user=api_user_json(g.user))


@app.route("/api/calculate", methods=["POST"])
@subscription_required
def api_calculate():
    d = request.get_json(silent=True) or {}
    try:
        rep = engine.run(d)
    except engine.InputError as e:
        return jsonify(error=str(e)), 400
    if d.get("save", True):
        save_calc(g.user, d)
    return jsonify(rep)


@app.route("/api/history")
@login_required
def api_history():
    rows = get_db().execute("SELECT id, title, input_json, created_at FROM calculations WHERE user_id=? "
                            "ORDER BY id DESC LIMIT 100", (g.user["id"],)).fetchall()
    return jsonify(items=[{"id": r["id"], "title": r["title"], "created_at": r["created_at"],
                           "input": json.loads(r["input_json"])} for r in rows])


@app.route("/api/payments", methods=["GET", "POST"])
@login_required
def api_payments():
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        ok, err = submit_payment(g.user, d.get("method"), d.get("txn_id"), d.get("sender_number"), d.get("months", 1))
        if not ok:
            return jsonify(error=err), 400
    rows = get_db().execute("SELECT id, method, txn_id, amount, months, status, note, created_at, reviewed_at "
                            "FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 50", (g.user["id"],)).fetchall()
    return jsonify(payments=[dict(r) for r in rows], subscription=subscription(g.user))


@app.route("/api/admin/payments")
@admin_required
def api_admin_payments():
    rows = get_db().execute("SELECT p.*, u.name, u.phone FROM payments p JOIN users u ON u.id=p.user_id "
                            "WHERE p.status=? ORDER BY p.id DESC LIMIT 200",
                            (request.args.get("status", "pending"),)).fetchall()
    return jsonify(payments=[dict(r) for r in rows])


@app.route("/api/admin/payments/<int:pid>", methods=["POST"])
@admin_required
def api_admin_payment_action(pid):
    d = request.get_json(silent=True) or {}
    db = get_db()
    p = db.execute("SELECT * FROM payments WHERE id=?", (pid,)).fetchone()
    if not p or p["status"] != "pending":
        return jsonify(error="not pending"), 400
    if d.get("action") == "approve":
        extend_subscription(db, p["user_id"], p["months"] * config.DAYS_PER_MONTH)
        db.execute("UPDATE payments SET status='approved', reviewed_at=? WHERE id=?", (ts(now()), pid))
    elif d.get("action") == "reject":
        db.execute("UPDATE payments SET status='rejected', note=?, reviewed_at=? WHERE id=?",
                   ((d.get("note") or "")[:200], ts(now()), pid))
    else:
        return jsonify(error="action must be approve or reject"), 400
    db.commit()
    return jsonify(ok=True)


@app.route("/api/plans")
def api_plans():
    return jsonify(trial_days=config.TRIAL_DAYS, package=config.PLAY_PACKAGE_NAME,
                   plans=[dict(key=k, **v) for k, v in config.PLANS.items()])


@app.route("/api/play/verify", methods=["POST"])
@login_required
def api_play_verify():
    """Called by the app right after a Google Play purchase (and on 'restore')."""
    d = request.get_json(silent=True) or {}
    tokens = d.get("purchase_tokens") or ([d.get("purchase_token")] if d.get("purchase_token") else [])
    if not tokens:
        return jsonify(error="purchase_token required"), 400
    results = []
    for t in tokens[:10]:
        try:
            info, plan, _ = apply_play_purchase(t, g.user["id"])
            results.append({"ok": True, "plan": plan, "state": info["state"], "expiry": ts(info["expiry"])})
        except play.PlayError as e:
            app.logger.warning("play verify failed: %s", e)
            results.append({"ok": False, "error": str(e)})
    user = get_db().execute("SELECT * FROM users WHERE id=?", (g.user["id"],)).fetchone()
    status = 200 if any(r["ok"] for r in results) else 400
    return jsonify(results=results, subscription=subscription(user)), status


@app.route("/api/play/rtdn", methods=["POST"])
def api_play_rtdn():
    """Google Cloud Pub/Sub push endpoint for Real-time Developer Notifications."""
    if not config.RTDN_SECRET or not secrets.compare_digest(request.args.get("secret", ""), config.RTDN_SECRET):
        abort(403)
    env = request.get_json(silent=True) or {}
    try:
        import base64
        data = json.loads(base64.b64decode((env.get("message") or {}).get("data") or "e30=").decode())
    except Exception:
        return jsonify(ok=True, ignored="bad payload")
    if data.get("packageName") and data["packageName"] != config.PLAY_PACKAGE_NAME:
        return jsonify(ok=True, ignored="other package")
    sn = data.get("subscriptionNotification")
    if not sn:
        return jsonify(ok=True, ignored="not a subscription notification")
    try:
        apply_play_purchase(sn.get("purchaseToken"))
    except play.PlayError as e:
        app.logger.warning("rtdn: %s", e)
        # 200 so Pub/Sub does not retry forever on a bad token; real errors are retried
        if "invalid" in str(e) or "unknown product" in str(e):
            return jsonify(ok=True, ignored=str(e))
        return jsonify(error=str(e)), 500
    return jsonify(ok=True)


@app.route("/.well-known/assetlinks.json")
def assetlinks():
    """Lets Android trust this website for the Play Store (TWA) app."""
    return jsonify([{
        "relation": ["delegate_permission/common.handle_all_urls"],
        "target": {"namespace": "android_app", "package_name": config.PLAY_PACKAGE_NAME,
                   "sha256_cert_fingerprints": config.ASSETLINKS_SHA256},
    }])


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify(error="not found"), 404
    return render_template("message.html", msg="صفحہ نہیں ملا"), 404


@app.errorhandler(403)
def forbidden(e):
    if request.path.startswith("/api/"):
        return jsonify(error="forbidden"), 403
    return render_template("message.html", msg="اجازت نہیں"), 403


# =========================================================== CLI
@app.cli.command("make-admin")
def make_admin_cmd():
    """flask --app app make-admin  -> asks phone and makes that user admin"""
    phone = norm_phone(input("Phone (03XXXXXXXXX): "))
    db = get_db()
    db.execute("UPDATE users SET is_admin=1 WHERE phone=?", (phone,))
    db.commit()
    print("done" if db.total_changes else "user not found - register first")


if __name__ == "__main__":
    app.run(debug=True)
