# Copy this into the WSGI file PythonAnywhere gives you
# (Web tab -> "WSGI configuration file"), replacing everything in it.
# Change YOURUSERNAME and the SECRET_KEY.
import os, sys

project = "/home/YOURUSERNAME/warasat-app"
if project not in sys.path:
    sys.path.insert(0, project)

os.environ["SECRET_KEY"] = "put-a-long-random-text-here"
os.environ["ADMIN_PHONES"] = "03007283456"

# Google Play Billing
os.environ["PLAY_PACKAGE_NAME"] = "com.warasat.calculator"
os.environ["GOOGLE_SERVICE_ACCOUNT_FILE"] = project + "/play-service-account.json"
os.environ["RTDN_SECRET"] = "choose-a-secret-word"      # same word as in the Pub/Sub push URL
os.environ["ASSETLINKS_SHA256"] = ""                      # SHA-256 from Play Console > App signing
# Plans (product IDs must match Play Console)
os.environ["PLAY_MONTHLY_ID"] = "warasat_monthly"
os.environ["PLAY_YEARLY_ID"] = "warasat_yearly"
os.environ["MONTHLY_PRICE"] = "50"
os.environ["YEARLY_PRICE"] = "500"

from app import app as application  # noqa
