"""Google Play billing flow with a fake Google server."""
import base64, json
from datetime import datetime, timedelta, timezone
from test_app import make_client
from warasat import play


def iso(days):
    return (datetime.now(timezone.utc) + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S.123456789Z")


class FakeGoogle:
    def __init__(self):
        self.subs = {}
        self.acked = []

    def add(self, token, product, days, state="SUBSCRIPTION_STATE_ACTIVE", acked=False, linked=None, order="GPA.1"):
        d = {"subscriptionState": state, "latestOrderId": order,
             "acknowledgementState": "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED" if acked else "ACKNOWLEDGEMENT_STATE_PENDING",
             "lineItems": [{"productId": product, "expiryTime": iso(days),
                            "autoRenewingPlan": {"autoRenewEnabled": state == "SUBSCRIPTION_STATE_ACTIVE"},
                            "offerDetails": {"basePlanId": "p"}}]}
        if linked:
            d["linkedPurchaseToken"] = linked
        self.subs[token] = d

    def get_subscription(self, token):
        if token not in self.subs:
            raise play.PlayError("invalid purchase token")
        return self.subs[token]

    def acknowledge(self, product_id, token):
        self.acked.append(token)
        self.subs[token]["acknowledgementState"] = "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED"


def setup():
    c = make_client()
    g = FakeGoogle()
    play.set_client(g)
    r = c.post("/api/register", json={"name": "U", "phone": "03001112223", "password": "secret1"})
    H = {"Authorization": "Bearer " + r.json["token"]}
    import app as appmod
    with appmod.app.app_context():   # end the free trial so we see the effect of paying
        db = appmod.get_db(); db.execute("UPDATE users SET trial_ends='2020-01-01 00:00:00'"); db.commit()
    return c, g, H, appmod


def rtdn(c, token, secret="s3cret"):
    data = base64.b64encode(json.dumps({"packageName": "com.warasat.calculator",
        "subscriptionNotification": {"notificationType": 13, "purchaseToken": token,
                                     "subscriptionId": "warasat_monthly"}}).encode()).decode()
    return c.post(f"/api/play/rtdn?secret={secret}", json={"message": {"data": data}})


def test_monthly_purchase_auto_activates_and_acks():
    c, g, H, _ = setup()
    assert c.post("/api/calculate", headers=H, json={"heirs": {"son": 1}}).status_code == 402
    g.add("tokM", "warasat_monthly", 30)
    r = c.post("/api/play/verify", headers=H, json={"purchase_token": "tokM"})
    assert r.status_code == 200 and r.json["results"][0]["plan"] == "monthly"
    assert g.acked == ["tokM"]
    s = r.json["subscription"]
    assert s["active"] and not s["on_trial"] and 29 <= s["days_left"] <= 31
    assert c.post("/api/calculate", headers=H, json={"heirs": {"son": 1}}).status_code == 200


def test_yearly_and_upgrade_and_expiry_via_rtdn():
    c, g, H, appmod = setup()
    g.add("tokM", "warasat_monthly", 30)
    c.post("/api/play/verify", headers=H, json={"purchase_token": "tokM"})
    g.add("tokY", "warasat_yearly", 365, linked="tokM")
    # webhook alone (no app call) links the new token to the same user via linkedPurchaseToken
    assert rtdn(c, "tokY").status_code == 200
    s = c.get("/api/me", headers=H).json["user"]["subscription"]
    assert s["days_left"] >= 364
    # refund / expiry -> access removed automatically
    g.add("tokY", "warasat_yearly", -1, state="SUBSCRIPTION_STATE_EXPIRED", acked=True, linked="tokM")
    rtdn(c, "tokY")
    s = c.get("/api/me", headers=H).json["user"]["subscription"]
    assert not s["active"]


def test_token_cannot_be_reused_by_other_account():
    c, g, H, _ = setup()
    g.add("tokX", "warasat_monthly", 30)
    assert c.post("/api/play/verify", headers=H, json={"purchase_token": "tokX"}).status_code == 200
    r = c.post("/api/register", json={"name": "V", "phone": "03004445556", "password": "secret1"})
    H2 = {"Authorization": "Bearer " + r.json["token"]}
    r = c.post("/api/play/verify", headers=H2, json={"purchase_token": "tokX"})
    assert r.status_code == 400


def test_fake_token_and_unknown_product_rejected():
    c, g, H, _ = setup()
    assert c.post("/api/play/verify", headers=H, json={"purchase_token": "nope"}).status_code == 400
    g.add("tokZ", "some_other_app_item", 30)
    assert c.post("/api/play/verify", headers=H, json={"purchase_token": "tokZ"}).status_code == 400


def test_rtdn_needs_secret_and_cancel_keeps_access_until_expiry():
    c, g, H, _ = setup()
    assert rtdn(c, "x", secret="wrong").status_code == 403
    g.add("tokC", "warasat_monthly", 10)
    c.post("/api/play/verify", headers=H, json={"purchase_token": "tokC"})
    g.add("tokC", "warasat_monthly", 10, state="SUBSCRIPTION_STATE_CANCELED", acked=True)
    rtdn(c, "tokC")
    s = c.get("/api/me", headers=H).json["user"]["subscription"]
    assert s["active"] and s["days_left"] in (10, 11)


def test_session_api_requires_csrf_header_and_admin_pages():
    import re
    c, g, H, appmod = setup()
    # admin web login
    r = c.post("/api/register", json={"name": "A", "phone": "03000000001", "password": "adminpw"})
    html = c.get("/login").get_data(as_text=True)
    tok = re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
    c.post("/login", data={"_csrf": tok, "phone": "03000000001", "password": "adminpw"})
    g.add("tokS", "warasat_yearly", 365)
    assert c.post("/api/play/verify", json={"purchase_token": "tokS"}).status_code == 400  # no csrf header
    html = c.get("/subscribe").get_data(as_text=True)
    tok = re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)
    assert c.post("/api/play/verify", json={"purchase_token": "tokS"}, headers={"X-CSRF-Token": tok}).status_code == 200
    html = c.get("/admin").get_data(as_text=True)
    assert "سالانہ" in html and "tokS" in html
    assert c.post("/admin/play/refresh", data={"_csrf": tok, "token": "tokS"}).status_code == 302
    u = c.get("/admin?q=0300111").get_data(as_text=True)
    assert "03001112223" in u
    assert c.get("/.well-known/assetlinks.json").json[0]["target"]["package_name"] == "com.warasat.calculator"
