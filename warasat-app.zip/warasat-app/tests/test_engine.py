"""Engine tests. Cases marked (xl) were checked against Warasat_v_3.9.xlsm."""
import os, sys, random
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from warasat.engine import calculate, build_report, run, HEIR_INFO

def each(heirs, fiqh="hanafi", law="mflo", ps=None, pd=None):
    rep = build_report(calculate(heirs, fiqh, law, ps, pd))
    return {r["key"]: (F(0) if r["excluded"] else F(r["each_share"])) for r in rep["rows"]}

def test_widow_sons_daughters_xl():
    e = each({"wife": 1, "son": 3, "daughter": 4})
    assert e == {"wife": F(1, 8), "son": F(7, 40), "daughter": F(7, 80)}

def test_umariyyatain_xl():
    assert each({"husband": 1, "mother": 1, "father": 1}) == {"husband": F(1, 2), "mother": F(1, 6), "father": F(1, 3)}

def test_awl_xl():
    assert each({"husband": 1, "full_sister": 2, "mother": 1}) == {"husband": F(3, 8), "full_sister": F(1, 4), "mother": F(1, 8)}

def test_radd_xl():
    assert each({"wife": 1, "daughter": 1, "mother": 1}) == {"wife": F(1, 8), "daughter": F(21, 32), "mother": F(7, 32)}

def test_mflo_lines_xl():
    e = each({"wife": 1, "son": 1}, ps=[{"sons": 1, "daughters": 2}], pd=[{"sons": 1}])
    assert e["son"] == F(7, 20) and e["pre_son_1_sons"] == F(7, 40)
    assert e["pre_son_1_daughters"] == F(7, 80) and e["pre_daughter_1_sons"] == F(7, 40)

def test_islamic_excludes_orphan_grandchild_with_son():
    e = each({"son": 1}, law="islamic", ps=[{"sons": 1}])
    assert e["son"] == 1

def test_himariyya_hanafi():
    e = each({"husband": 1, "mother": 1, "uterine": 2, "full_brother": 2})
    assert e["full_brother"] == 0 and e["uterine"] == F(1, 6)

def test_grandfather_excludes_brothers_hanafi_xl():
    assert each({"wife": 1, "full_brother": 1, "grandfather": 1})["full_brother"] == 0

def test_sister_asaba_with_daughter():
    assert each({"daughter": 1, "full_sister": 1}) == {"daughter": F(1, 2), "full_sister": F(1, 2)}
    assert each({"son_daughter": 3, "pat_sister": 1}, law="islamic")["pat_sister"] == F(1, 3)

def test_lower_male_makes_granddaughter_asaba():
    e = each({"daughter": 2, "son_daughter": 2, "sss": 1}, law="islamic")
    assert e == {"daughter": F(1, 3), "son_daughter": F(1, 12), "sss": F(1, 6)}

def test_spouse_alone_gets_all():
    assert each({"husband": 1}) == {"husband": 1}
    assert each({"wife": 2}) == {"wife": F(1, 2)}

def test_jafari_xl():
    assert each({"husband": 1, "mother": 1, "father": 1}, "jafari") == {"husband": F(1, 2), "mother": F(1, 3), "father": F(1, 6)}
    assert each({"wife": 1, "daughter": 1, "mother": 1, "father": 1}, "jafari") == \
        {"wife": F(1, 8), "mother": F(7, 40), "father": F(7, 40), "daughter": F(21, 40)}
    assert each({"husband": 1, "daughter": 2, "mother": 1, "father": 1}, "jafari") == \
        {"husband": F(1, 4), "mother": F(1, 6), "father": F(1, 6), "daughter": F(5, 24)}
    assert each({"wife": 1, "full_brother": 1, "full_sister": 1, "grandfather": 1}, "jafari") == \
        {"wife": F(1, 4), "full_brother": F(3, 10), "grandfather": F(3, 10), "full_sister": F(3, 20)}

def test_jafari_representation():
    e = each({"father": 1, "son_daughter": 1}, "jafari", "islamic")
    assert e == {"father": F(1, 6), "son_daughter": F(5, 6)}

def test_area_split_xl():
    rep = run({"heirs": {"wife": 1, "son": 3, "daughter": 4}, "area": {"kanal": 2, "unit": "foot"}, "amount": 800000})
    rows = {r["key"]: r for r in rep["rows"]}
    assert rows["wife"]["each_area"]["marla"] == 5
    assert rows["son"]["each_area"] == {"kanal": 0, "marla": 7, "sub": 0.0, "total_marla": 7.0}
    assert rows["daughter"]["each_area"]["sub"] == 136.0
    assert rows["son"]["each_amount"] == 140000.0
    assert rep["total_hisay"] == 80

def test_fuzz_shares_sum_to_one():
    rnd = random.Random(1)
    keys = list(HEIR_INFO)
    for _ in range(3000):
        h = {k: rnd.randint(1, 3) for k in rnd.sample(keys, rnd.randint(1, 6))}
        if "husband" in h and "wife" in h:
            del h["wife"]
        for k in ("husband", "mother", "father", "grandfather", "pat_grandmother", "mat_grandmother"):
            if k in h: h[k] = 1
        ps = [{"sons": rnd.randint(0, 2), "daughters": rnd.randint(0, 2)}] if rnd.random() < .3 else None
        pd = [{"sons": rnd.randint(0, 2), "daughters": rnd.randint(0, 2)}] if rnd.random() < .3 else None
        for fiqh in ("hanafi", "jafari"):
            for law in ("mflo", "islamic"):
                try:
                    res = calculate(dict(h), fiqh, law, ps, pd)
                except Exception as ex:
                    if "کوئی وارث" in str(ex): continue
                    raise
                total = sum(i.share for i in res.items) + res.unallocated
                assert total == 1, (h, ps, pd, fiqh, law, total)
                assert all(i.share >= 0 for i in res.items)
