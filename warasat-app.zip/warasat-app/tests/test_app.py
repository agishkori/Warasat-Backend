import os, re, tempfile, importlib, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def make_client(manual=False):
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    os.environ["DATABASE"] = path
    os.environ["ENABLE_MANUAL_PAYMENTS"] = "1" if manual else "0"
    os.environ["RTDN_SECRET"] = "s3cret"
    os.environ["ADMIN_PHONES"] = "03000000001"
    import config; importlib.reload(config)
    import app as appmod; importlib.reload(appmod)
    appmod.app.config["TESTING"] = True
    return appmod.app.test_client()

def test_api_flow():
    c = make_client(manual=True)
    r = c.post("/api/register", json={"name": "Ali", "phone": "03001234567", "password": "secret1"})
    assert r.status_code == 200, r.json
    tok = r.json["token"]; H = {"Authorization": "Bearer " + tok}
    assert r.json["user"]["subscription"]["on_trial"]
    r = c.post("/api/calculate", headers=H, json={"heirs": {"wife": 1, "son": 3, "daughter": 4},
              "area": {"kanal": 2, "unit": "foot"}})
    assert r.status_code == 200, r.json
    rows = {x["key"]: x for x in r.json["rows"]}
    assert rows["wife"]["each_share"] == "1/8"
    assert rows["son"]["each_share"] == "7/40"
    assert rows["daughter"]["each_area"] == {"kanal": 0, "marla": 3, "sub": 136.0, "total_marla": 3.5}
    # duplicate phone
    assert c.post("/api/register", json={"name": "X", "phone": "03001234567", "password": "secret1"}).status_code == 400
    # payment
    r = c.post("/api/payments", headers=H, json={"method": "jazzcash", "txn_id": "TX12345678", "months": 2})
    assert r.status_code == 200 and r.json["payments"][0]["amount"] == 100
    assert c.post("/api/payments", headers=H, json={"method": "jazzcash", "txn_id": "TX12345678"}).status_code == 400
    # non admin can't approve
    pid = r.json["payments"][0]["id"]
    assert c.post(f"/api/admin/payments/{pid}", headers=H, json={"action": "approve"}).status_code == 403
    # admin
    r = c.post("/api/register", json={"name": "Admin", "phone": "03000000001", "password": "adminpw"})
    AH = {"Authorization": "Bearer " + r.json["token"]}
    assert len(c.get("/api/admin/payments", headers=AH).json["payments"]) == 1
    assert c.post(f"/api/admin/payments/{pid}", headers=AH, json={"action": "approve"}).json["ok"]
    me = c.get("/api/me", headers=H).json["user"]["subscription"]
    assert me["active"] and me["days_left"] >= 89

def test_expired_blocks_calc():
    c = make_client()
    r = c.post("/api/register", json={"name": "B", "phone": "03111111111", "password": "secret1"})
    H = {"Authorization": "Bearer " + r.json["token"]}
    import app as appmod
    with appmod.app.app_context():
        db = appmod.get_db(); db.execute("UPDATE users SET trial_ends='2020-01-01 00:00:00'"); db.commit()
    r = c.post("/api/calculate", headers=H, json={"heirs": {"son": 1}})
    assert r.status_code == 402

def test_web_pages():
    c = make_client()
    html = c.get("/register").get_data(as_text=True)
    tok = re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
    r = c.post("/register", data={"_csrf": tok, "name": "C", "phone": "03222222222", "password": "secret1"})
    assert r.status_code == 302
    html = c.get("/calc").get_data(as_text=True)
    assert "وراثت کا حساب" in html
    tok = re.search(r'name="_csrf" value="([^"]+)"', html).group(1)
    r = c.post("/calc", data={"_csrf": tok, "h_husband": "1", "h_mother": "1", "h_father": "1", "kanal": "1", "amount": "600000"})
    html = r.get_data(as_text=True)
    assert "1/2" in html and "1/6" in html and "1/3" in html, html[:3000]
    assert c.get("/history").status_code == 200
    assert c.get("/subscribe").status_code == 200
    assert c.get("/admin").status_code == 403

def test_manual_payments_off_by_default():
    c = make_client()
    r = c.post("/api/register", json={"name": "D", "phone": "03333333333", "password": "secret1"})
    H = {"Authorization": "Bearer " + r.json["token"]}
    assert c.post("/api/payments", headers=H, json={"method": "jazzcash", "txn_id": "TX99999999"}).status_code == 400
