"""App settings. Values can be overridden with environment variables
(on PythonAnywhere set them at the top of the WSGI file)."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# CHANGE THIS on the server (any long random text)
SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-please-very-secret")

DATABASE = os.environ.get("DATABASE", os.path.join(BASE_DIR, "warasat.db"))

APP_NAME = "وراثت کیلکولیٹر"

# ------------------------------------------------------------------ subscription
TRIAL_DAYS = int(os.environ.get("TRIAL_DAYS", 30))

# Each plan = one *subscription product* in Google Play Console
# (Monetize > Subscriptions). The product_id here must match exactly.
PLANS = {
    "monthly": {
        "product_id": os.environ.get("PLAY_MONTHLY_ID", "warasat_monthly"),
        "price": int(os.environ.get("MONTHLY_PRICE", 50)),
        "days": 30,
        "label_ur": "ماہانہ",
        "period_ur": "مہینہ",
    },
    "yearly": {
        "product_id": os.environ.get("PLAY_YEARLY_ID", "warasat_yearly"),
        "price": int(os.environ.get("YEARLY_PRICE", 500)),
        "days": 365,
        "label_ur": "سالانہ",
        "period_ur": "سال",
    },
}
MONTHLY_PRICE = PLANS["monthly"]["price"]
DAYS_PER_MONTH = 30

# ------------------------------------------------------------------ Google Play
# Android app package name (the one you give Bubblewrap / Play Console)
PLAY_PACKAGE_NAME = os.environ.get("PLAY_PACKAGE_NAME", "com.warasat.calculator")
# Path of the service-account JSON key that has access to Play Console
GOOGLE_SERVICE_ACCOUNT_FILE = os.environ.get(
    "GOOGLE_SERVICE_ACCOUNT_FILE", os.path.join(BASE_DIR, "play-service-account.json"))
# Secret word added to the Pub/Sub push URL: /api/play/rtdn?secret=XXXX
RTDN_SECRET = os.environ.get("RTDN_SECRET", "")
# SHA-256 fingerprint(s) of your app signing key, comma separated (Play Console >
# Setup > App signing). Used for /.well-known/assetlinks.json (needed by the TWA).
ASSETLINKS_SHA256 = [s.strip() for s in os.environ.get("ASSETLINKS_SHA256", "").split(",") if s.strip()]

# ------------------------------------------------------------------ manual payments
# Off by default: Play Store apps must take payment through Google Play Billing.
ENABLE_MANUAL_PAYMENTS = os.environ.get("ENABLE_MANUAL_PAYMENTS", "0") == "1"
PAYMENT_ACCOUNTS = [
    {"method": "jazzcash", "name": "JazzCash", "number": os.environ.get("JAZZCASH_NUMBER", "03007283456")},
    {"method": "easypaisa", "name": "EasyPaisa", "number": os.environ.get("EASYPAISA_NUMBER", "03007283456")},
]
ACCOUNT_TITLE = os.environ.get("ACCOUNT_TITLE", "")

# Phone numbers that automatically become admins when they register
ADMIN_PHONES = [p.strip() for p in os.environ.get("ADMIN_PHONES", "03007283456").split(",") if p.strip()]
