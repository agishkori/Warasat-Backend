// Google Play Billing inside the Play Store app (Trusted Web Activity).
// Uses the Digital Goods API + Payment Request API; the server verifies with Google.
(function () {
  const PLAY = "https://play.google.com/billing";
  const msg = document.getElementById("billing-msg");
  const notInApp = document.getElementById("not-in-app");
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  let service = null;

  function say(text, bad) {
    msg.textContent = text;
    msg.className = bad ? "flash error" : "flash";
  }

  async function sendToServer(tokens) {
    const r = await fetch("/api/play/verify", {
      method: "POST",
      credentials: "same-origin",
      headers: {"Content-Type": "application/json", "X-CSRF-Token": csrf},
      body: JSON.stringify({purchase_tokens: tokens}),
    });
    return r.json().then(j => ({ok: r.ok, body: j}));
  }

  async function buy(sku) {
    const request = new PaymentRequest(
      [{supportedMethods: PLAY, data: {sku: sku}}],
      {total: {label: "Total", amount: {currency: "PKR", value: "0"}}}  // ignored by Play
    );
    let response;
    try {
      response = await request.show();
    } catch (e) {
      say("خریداری مکمل نہیں ہوئی۔", true);
      return;
    }
    const token = response.details.purchaseToken || response.details.token;
    say("ادائیگی کی تصدیق ہو رہی ہے…");
    try {
      const res = await sendToServer([token]);
      await response.complete(res.ok ? "success" : "fail");
      if (res.ok) {
        say("شکریہ! آپ کا اکاؤنٹ فعال ہو گیا۔");
        setTimeout(() => location.reload(), 1200);
      } else {
        say("تصدیق نہیں ہو سکی، تھوڑی دیر بعد 'پرانی خریداری بحال کریں' دبائیں۔", true);
      }
    } catch (e) {
      await response.complete("fail");
      say("انٹرنیٹ کا مسئلہ — بعد میں 'پرانی خریداری بحال کریں' دبائیں۔", true);
    }
  }

  async function restore() {
    const purchases = await service.listPurchases();
    if (!purchases.length) { say("اس Google اکاؤنٹ پر کوئی فعال خریداری نہیں ملی۔", true); return; }
    say("تصدیق ہو رہی ہے…");
    const res = await sendToServer(purchases.map(p => p.purchaseToken));
    if (res.ok) { say("خریداری بحال ہو گئی۔"); setTimeout(() => location.reload(), 1200); }
    else say((res.body.results && res.body.results[0] && res.body.results[0].error) || "بحال نہیں ہو سکی", true);
  }

  async function init() {
    if (!("getDigitalGoodsService" in window)) { notInApp.hidden = false; return; }
    try {
      service = await window.getDigitalGoodsService(PLAY);
    } catch (e) { notInApp.hidden = false; return; }
    if (!service) { notInApp.hidden = false; return; }

    const skus = [...document.querySelectorAll(".js-buy")].map(b => b.dataset.sku);
    try {
      const details = await service.getDetails(skus);
      for (const d of details) {
        const el = document.querySelector(`.js-price[data-sku="${d.itemId}"]`);
        if (el && d.price) {
          el.textContent = new Intl.NumberFormat("ur-PK", {style: "currency", currency: d.price.currency})
            .format(d.price.value);
        }
      }
    } catch (e) { /* keep server prices */ }

    document.querySelectorAll(".js-buy").forEach(b => {
      b.disabled = false;
      b.addEventListener("click", () => buy(b.dataset.sku));
    });
    const r = document.querySelector(".js-restore");
    r.disabled = false;
    r.addEventListener("click", restore);

    // silently re-link an existing subscription (e.g. new phone / reinstall)
    try {
      const existing = await service.listPurchases();
      if (existing.length && document.body.dataset.subActive !== "1") {
        const res = await sendToServer(existing.map(p => p.purchaseToken));
        if (res.ok) location.reload();
      }
    } catch (e) { /* ignore */ }
  }
  init();
})();
