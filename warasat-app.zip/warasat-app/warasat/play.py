"""
Google Play Billing — server side verification.

Flow
  1. Android app (TWA) buys a subscription with the Digital Goods + Payment Request API
  2. the page sends the purchaseToken to /api/play/verify
  3. we ask Google (Play Developer API, subscriptionsv2) whether it is real & active,
     acknowledge it (otherwise Google refunds after 3 days) and extend the account.
  4. Google later tells us about renewals / cancellations / refunds through
     Real-time Developer Notifications (Pub/Sub push to /api/play/rtdn) and we
     re-check the token -> fully automatic, no admin approval needed.
"""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from typing import Optional

API = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications"
SCOPE = "https://www.googleapis.com/auth/androidpublisher"

ENTITLED_STATES = {
    "SUBSCRIPTION_STATE_ACTIVE",
    "SUBSCRIPTION_STATE_IN_GRACE_PERIOD",
    "SUBSCRIPTION_STATE_CANCELED",          # cancelled but paid period not over yet
}
STATE_UR = {
    "SUBSCRIPTION_STATE_ACTIVE": "فعال",
    "SUBSCRIPTION_STATE_IN_GRACE_PERIOD": "رعایتی مدت (ادائیگی میں مسئلہ)",
    "SUBSCRIPTION_STATE_ON_HOLD": "معطل (ادائیگی نہیں ہوئی)",
    "SUBSCRIPTION_STATE_PAUSED": "روکی ہوئی",
    "SUBSCRIPTION_STATE_CANCELED": "منسوخ (مدت ختم ہونے تک فعال)",
    "SUBSCRIPTION_STATE_EXPIRED": "ختم",
    "SUBSCRIPTION_STATE_PENDING": "ادائیگی زیرِ التوا",
    "SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED": "منسوخ",
}


class PlayError(Exception):
    pass


class GooglePlayClient:
    """Real client. Needs `google-auth` and `requests` and a service-account key."""

    def __init__(self, package_name: str, key_file: str):
        self.package = package_name
        self.key_file = key_file
        self._creds = None
        self._lock = threading.Lock()

    def _session(self):
        try:
            from google.auth.transport.requests import AuthorizedSession
            from google.oauth2 import service_account
        except ImportError as e:  # pragma: no cover
            raise PlayError("google-auth not installed: pip install google-auth requests") from e
        with self._lock:
            if self._creds is None:
                try:
                    self._creds = service_account.Credentials.from_service_account_file(
                        self.key_file, scopes=[SCOPE])
                except FileNotFoundError as e:
                    raise PlayError(f"service account key not found: {self.key_file}") from e
        return AuthorizedSession(self._creds)

    def get_subscription(self, token: str) -> dict:
        url = f"{API}/{self.package}/purchases/subscriptionsv2/tokens/{token}"
        r = self._session().get(url, timeout=20)
        if r.status_code in (400, 404, 410):
            raise PlayError("invalid purchase token")
        if r.status_code != 200:
            raise PlayError(f"Google API error {r.status_code}: {r.text[:300]}")
        return r.json()

    def acknowledge(self, product_id: str, token: str) -> None:
        url = f"{API}/{self.package}/purchases/subscriptions/{product_id}/tokens/{token}:acknowledge"
        r = self._session().post(url, json={}, timeout=20)
        if r.status_code not in (200, 204):
            raise PlayError(f"acknowledge failed {r.status_code}: {r.text[:300]}")


_client = None


def get_client():
    global _client
    if _client is None:
        import config
        _client = GooglePlayClient(config.PLAY_PACKAGE_NAME, config.GOOGLE_SERVICE_ACCOUNT_FILE)
    return _client


def set_client(c):
    """Tests use this to plug in a fake Google."""
    global _client
    _client = c


# --------------------------------------------------------------------- parsing
def _parse_time(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    if "." in s:  # trim nanoseconds to microseconds
        head, frac = s.split(".", 1)
        digits = "".join(ch for ch in frac if ch.isdigit())
        rest = frac[len(digits):]
        s = f"{head}.{digits[:6]}{rest}"
    return datetime.fromisoformat(s).astimezone(timezone.utc).replace(tzinfo=None)


def parse_subscription(data: dict) -> dict:
    items = data.get("lineItems") or []
    if not items:
        raise PlayError("no line items in purchase")
    # latest-expiring line item
    best = max(items, key=lambda li: _parse_time(li.get("expiryTime")) or datetime.min)
    return {
        "state": data.get("subscriptionState", ""),
        "product_id": best.get("productId"),
        "base_plan": (best.get("offerDetails") or {}).get("basePlanId"),
        "expiry": _parse_time(best.get("expiryTime")),
        "auto_renewing": bool((best.get("autoRenewingPlan") or {}).get("autoRenewEnabled")),
        "acknowledged": data.get("acknowledgementState") == "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED",
        "order_id": data.get("latestOrderId"),
        "linked_token": data.get("linkedPurchaseToken"),
        "test": "testPurchase" in data,
        "raw": json.dumps(data)[:4000],
    }
