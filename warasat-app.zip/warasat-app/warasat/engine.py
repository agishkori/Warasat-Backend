"""
Warasat (Islamic inheritance) calculation engine.

Re-implements the logic of the "Wrasat" sheet of Warasat_v_3.9.xlsm:
  * Fiqh Hanafi and Fiqh Jafaria
  * Muslim Family Laws Ordinance 1961 (section 4: children of a predeceased
    son / daughter take the share their parent would have taken) or plain
    Islamic law
  * Awl (عول) and Radd (رد)
  * Division of land (Kanal / Marla / Foot|Sarsai|Yard) and of a cash amount

All arithmetic uses exact fractions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction as F
from math import lcm
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Heir catalogue (row numbers refer to the Excel "Wrasat" sheet)
# ---------------------------------------------------------------------------
HEIRS = [
    # key,             urdu label,               english,                   sex, row
    ("husband",        "شوہر",                    "Husband",                 "m", 10),
    ("wife",           "بیوہ",                    "Wife / Widow",            "f", 11),
    ("mother",         "ماں",                     "Mother",                  "f", 12),
    ("pat_grandmother", "دادی",                   "Paternal grandmother",    "f", 13),
    ("mat_grandmother", "نانی",                   "Maternal grandmother",    "f", 14),
    ("father",         "باپ",                     "Father",                  "m", 15),
    ("grandfather",    "دادا",                    "Paternal grandfather",    "m", 16),
    ("son",            "بیٹا",                    "Son",                     "m", 17),
    ("daughter",       "بیٹی",                    "Daughter",                "f", 18),
    ("full_brother",   "حقیقی بھائی",              "Full brother",            "m", 19),
    ("full_sister",    "حقیقی بہن",               "Full sister",             "f", 20),
    ("uterine",        "مادری بھائی بہن",          "Uterine brother/sister",  "x", 21),
    ("son_son",        "پوتا",                    "Son's son",               "m", 23),
    ("son_daughter",   "پوتی",                    "Son's daughter",          "f", 24),
    ("sss",            "پڑپوتا",                  "Son's son's son",         "m", 25),
    ("ssd",            "پڑپوتی",                  "Son's son's daughter",    "f", 26),
    ("pat_brother",    "پدری بھائی",               "Paternal half brother",   "m", 27),
    ("pat_sister",     "پدری بہن",                "Paternal half sister",    "f", 28),
]
HEIR_INFO = {h[0]: {"ur": h[1], "en": h[2], "sex": h[3], "row": h[4]} for h in HEIRS}

UNITS_PER_MARLA = {"foot": 272, "sarsai": 9, "yard": 30}
UNIT_UR = {"foot": "فٹ", "sarsai": "سرسائی", "yard": "گز"}


class InputError(ValueError):
    pass


@dataclass
class Item:
    """One group of identical heirs (or one predeceased child's line)."""
    key: str
    count: int
    sex: str                       # m / f / x
    label_ur: str
    label_en: str
    share: F = F(0)                # share of the whole group
    fixed: F = F(0)
    asaba: bool = False
    weight: int = 1                # 2 for male in asaba, 1 for female
    excluded_reason: str = ""
    line: Optional[dict] = None    # for predeceased-child lines


@dataclass
class Result:
    items: List[Item] = field(default_factory=list)
    status: str = "equal"          # awl / radd / equal
    notes: List[str] = field(default_factory=list)
    unallocated: F = F(0)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _split_fixed(items: List[Item], total: F):
    """Divide a fixed share between items per head."""
    heads = sum(i.count for i in items)
    for i in items:
        i.fixed += total * i.count / heads


def _mk(key, count, sex=None, ur=None, en=None, line=None) -> Item:
    info = HEIR_INFO.get(key, {})
    return Item(key=key, count=count, sex=sex or info.get("sex", "x"),
                label_ur=ur or info.get("ur", key), label_en=en or info.get("en", key),
                line=line)


def _int(v, name, maximum=500) -> int:
    if v in (None, ""):
        return 0
    try:
        n = int(v)
    except (TypeError, ValueError):
        raise InputError(f"{name}: number required")
    if n < 0 or n > maximum:
        raise InputError(f"{name}: must be between 0 and {maximum}")
    return n


# ---------------------------------------------------------------------------
# main entry
# ---------------------------------------------------------------------------
def calculate(heirs: Dict[str, int], fiqh: str = "hanafi", law: str = "mflo",
              predeceased_sons: Optional[List[dict]] = None,
              predeceased_daughters: Optional[List[dict]] = None) -> Result:
    """
    heirs: {"wife": 1, "son": 3, "daughter": 4, ...}
    fiqh: "hanafi" | "jafari"
    law:  "mflo" (Muslim Family Laws Ordinance 1961) | "islamic"
    predeceased_sons / predeceased_daughters: [{"sons": 1, "daughters": 2}, ...]
        children of a son/daughter who died before the deceased.
    """
    fiqh = (fiqh or "hanafi").lower()
    law = (law or "mflo").lower()
    if fiqh not in ("hanafi", "jafari"):
        raise InputError("fiqh must be hanafi or jafari")
    if law not in ("mflo", "islamic"):
        raise InputError("law must be mflo or islamic")

    c = {k: _int(heirs.get(k), k) for k in HEIR_INFO}
    unknown = set(heirs) - set(HEIR_INFO)
    if unknown:
        raise InputError("unknown heir: " + ", ".join(sorted(unknown)))
    if c["husband"] and c["wife"]:
        raise InputError("شوہر اور بیوہ دونوں ایک ساتھ نہیں ہو سکتے")
    if c["husband"] > 1:
        raise InputError("شوہر صرف ایک ہو سکتا ہے")
    if c["wife"] > 4:
        raise InputError("بیوہ زیادہ سے زیادہ 4")
    for k in ("mother", "father", "grandfather", "pat_grandmother", "mat_grandmother"):
        if c[k] > 1:
            raise InputError(f"{HEIR_INFO[k]['ur']} صرف ایک ہو سکتا/سکتی ہے")

    lines = []
    for kind, lst in (("son", predeceased_sons or []), ("daughter", predeceased_daughters or [])):
        for idx, ln in enumerate(lst, 1):
            s = _int(ln.get("sons"), "sons")
            d = _int(ln.get("daughters"), "daughters")
            if s + d == 0:
                continue
            lines.append({"kind": kind, "n": idx, "sons": s, "daughters": d})

    pre_notes = []
    if law == "mflo" and c["son"] == 0 and (c["son_son"] or c["son_daughter"]):
        # No living son: the grandchildren's father must have died before the
        # deceased, so under MFLO s.4 they take their father's share.
        n = sum(1 for ln in lines if ln["kind"] == "son") + 1
        lines.append({"kind": "son", "n": n, "sons": c["son_son"], "daughters": c["son_daughter"]})
        c["son_son"] = c["son_daughter"] = 0
        pre_notes.append("پوتا/پوتی کو فوت شدہ بیٹے کی اولاد مان کر ان کے والد کا حصہ دیا گیا (MFLO دفعہ 4)")
    elif law == "mflo" and c["son"] and (c["son_son"] or c["son_daughter"]):
        pre_notes.append("اگر پوتا/پوتی کا والد متوفی سے پہلے فوت ہو چکا ہو تو انہیں 'فوت شدہ بیٹے کی اولاد' والے خانہ میں درج کریں")

    if fiqh == "hanafi":
        res = _hanafi(c, lines, law)
    else:
        res = _jafari(c, lines, law)

    if not any(i.share for i in res.items):
        raise InputError("کوئی وارث درج نہیں کیا گیا")
    res.notes = pre_notes + res.notes
    return res


# ---------------------------------------------------------------------------
# Predeceased-child lines
# ---------------------------------------------------------------------------
def _line_item(ln) -> Item:
    if ln["kind"] == "son":
        ur = f"فوت شدہ بیٹا {ln['n']} کی اولاد"
        en = f"Children of predeceased son {ln['n']}"
        sex = "m"
    else:
        ur = f"فوت شدہ بیٹی {ln['n']} کی اولاد"
        en = f"Children of predeceased daughter {ln['n']}"
        sex = "f"
    return Item(key=f"pre_{ln['kind']}_{ln['n']}", count=1, sex=sex,
                label_ur=ur, label_en=en, line=ln)


# ---------------------------------------------------------------------------
# Common finishing: residue, awl, radd
# ---------------------------------------------------------------------------
def _finish(items: List[Item], res: Result, radd_exclude=("husband", "wife"),
            radd_only: Optional[List[str]] = None, jafari=False,
            deficit_keys: Optional[List[str]] = None):
    active = [i for i in items if not i.excluded_reason]
    total_fixed = sum((i.fixed for i in active), F(0))
    asaba = [i for i in active if i.asaba]

    if jafari and total_fixed > 1 and deficit_keys:
        # Fiqh Jafaria has no awl: daughters / sisters bear the shortfall
        bearers = [i for i in active if i.key in deficit_keys and i.fixed]
        others = sum((i.fixed for i in active if i not in bearers), F(0))
        remaining = max(F(0), 1 - others)
        b_total = sum((i.fixed for i in bearers), F(0))
        for b in bearers:
            b.fixed = remaining * b.fixed / b_total
        total_fixed = sum((i.fixed for i in active), F(0))
        res.notes.append("فقہ جعفریہ میں عول نہیں ہوتا، کمی بیٹیوں/بہنوں کے حصہ سے پوری کی گئی")

    for i in active:
        i.share = i.fixed

    if asaba:
        residue = 1 - total_fixed
        if residue < 0:
            # awl, asaba get nothing beyond their fixed share
            for i in active:
                i.share = i.fixed / total_fixed
            res.status = "awl"
            for a in asaba:
                if not a.fixed:
                    a.excluded_reason = "ترکہ ذوی الفروض میں ختم ہو گیا"
            return
        tw = sum(a.count * a.weight for a in asaba)
        for a in asaba:
            a.share = a.fixed + residue * a.count * a.weight / tw
        if residue == 0:
            for a in asaba:
                if not a.fixed:
                    a.excluded_reason = "ترکہ ذوی الفروض میں ختم ہو گیا"
        res.status = "equal"
        return

    if total_fixed > 1:
        for i in active:
            i.share = i.fixed / total_fixed
        res.status = "awl"
        res.notes.append("عمل عول: ذوی الفروض کے حصے ترکہ سے زیادہ تھے، سب کے حصص تناسب سے کم کیے گئے")
        return
    if total_fixed == 1:
        res.status = "equal"
        return

    # radd
    surplus = 1 - total_fixed
    if radd_only is not None:
        receivers = [i for i in active if i.key in radd_only and i.fixed]
    else:
        receivers = [i for i in active if i.key not in radd_exclude and i.fixed]
    if not receivers:
        spouses = [i for i in active if i.key in ("husband", "wife")]
        if spouses and not jafari:
            receivers = spouses
            res.notes.append("کوئی اور وارث نہ ہونے پر بقیہ ترکہ بھی شریکِ حیات کو رد کیا گیا")
        elif spouses and jafari and spouses[0].key == "husband":
            receivers = spouses
            res.notes.append("فقہ جعفریہ: کوئی اور وارث نہ ہونے پر بقیہ ترکہ شوہر کو رد کیا گیا")
        else:
            res.unallocated = surplus
            res.notes.append("بقیہ ترکہ کا کوئی وارث درج نہیں (بیت المال / دیگر رشتہ دار)")
            res.status = "radd"
            return
    rt = sum(i.fixed for i in receivers)
    for i in receivers:
        i.share = i.fixed + surplus * i.fixed / rt
    res.status = "radd"
    res.notes.append("عمل رد: بچا ہوا ترکہ ذوی الفروض میں ان کے حصوں کے تناسب سے واپس تقسیم کیا گیا")


# ---------------------------------------------------------------------------
# Fiqh Hanafi
# ---------------------------------------------------------------------------
def _hanafi(c, lines, law) -> Result:
    res = Result()
    items: List[Item] = []
    add = lambda it: (items.append(it), it)[1]

    # predeceased-child lines
    pre_sons, pre_daus = [], []
    for ln in lines:
        it = _line_item(ln)
        if law == "mflo":
            (pre_sons if ln["kind"] == "son" else pre_daus).append(add(it))
        else:
            add(it)
            if ln["kind"] == "son":
                # Islamic law: son's children are ordinary grandchildren
                c["son_son"] += ln["sons"]
                c["son_daughter"] += ln["daughters"]
                it.excluded_reason = "اسلامی قانون: پوتا/پوتی کے خانہ میں شامل کیے گئے"
            else:
                it.excluded_reason = "اسلامی قانون: نواسہ/نواسی ذوی الارحام ہیں (محروم)"
    if lines and law == "mflo":
        res.notes.append("مسلم فیملی لاء آرڈیننس 1961 دفعہ 4: فوت شدہ بیٹے/بیٹی کی اولاد کو ان کے والدین کا حصہ دیا گیا")

    n_sons = c["son"] + len(pre_sons)
    n_daus = c["daughter"] + len(pre_daus)

    # descendant levels
    levels = [
        ([("son", c["son"])] , [("daughter", c["daughter"])]),
        ([("son_son", c["son_son"])], [("son_daughter", c["son_daughter"])]),
        ([("sss", c["sss"])], [("ssd", c["ssd"])]),
    ]
    lvl_items = []
    for li, (ms, fs) in enumerate(levels):
        mi = [add(_mk(k, n)) for k, n in ms if n]
        fi = [add(_mk(k, n)) for k, n in fs if n]
        if li == 0:
            mi += pre_sons
            fi += pre_daus
        lvl_items.append((mi, fi))

    male_desc = any(bool(mi) for mi, _ in lvl_items)
    any_desc = any(bool(mi or fi) for mi, fi in lvl_items)
    female_only_desc = any_desc and not male_desc

    M = next((k for k, (m, _) in enumerate(lvl_items) if m), None)
    used = F(0)
    joiners = []
    for k, (mi, fi) in enumerate(lvl_items):
        if M is not None and k > M:
            for it in mi + fi:
                it.excluded_reason = "قریبی مرد اولاد کی موجودگی میں محروم"
            continue
        if k == M:
            for it in mi:
                it.asaba, it.weight = True, 2
            for it in fi:
                it.asaba, it.weight = True, 1
            for it in joiners:
                it.asaba, it.weight, it.excluded_reason = True, 1, ""
            continue
        if not fi:
            continue
        heads = sum(i.count for i in fi)
        if used == 0:
            sh = F(1, 2) if heads == 1 else F(2, 3)
        elif used == F(1, 2):
            sh = F(1, 6)
        else:
            sh = F(0)
        if sh:
            _split_fixed(fi, sh)
            used += sh
        else:
            for it in fi:
                it.excluded_reason = "اوپر والی بیٹیوں نے 2/3 لے لیا"
                joiners.append(it)

    # spouse
    if c["husband"]:
        h = add(_mk("husband", 1))
        h.fixed = F(1, 4) if any_desc else F(1, 2)
    if c["wife"]:
        w = add(_mk("wife", c["wife"]))
        w.fixed = F(1, 8) if any_desc else F(1, 4)
    spouse_share = F(1, 4) if (c["husband"] and any_desc) else F(1, 2) if c["husband"] else \
        (F(1, 8) if any_desc else F(1, 4)) if c["wife"] else F(0)

    siblings_total = c["full_brother"] + c["full_sister"] + c["pat_brother"] + c["pat_sister"] + c["uterine"]
    father = c["father"] > 0
    gf = c["grandfather"] > 0 and not father

    # mother
    if c["mother"]:
        m = add(_mk("mother", 1))
        if any_desc or siblings_total >= 2:
            m.fixed = F(1, 6)
        elif father and (c["husband"] or c["wife"]):
            m.fixed = (1 - spouse_share) / 3        # Umariyyatain
            res.notes.append("مسئلہ عمریتین: ماں کو شریکِ حیات کا حصہ نکال کر بقیہ کا 1/3 دیا گیا")
        else:
            m.fixed = F(1, 3)

    # grandmothers
    gms = []
    if c["pat_grandmother"]:
        it = add(_mk("pat_grandmother", 1))
        if c["mother"]:
            it.excluded_reason = "ماں کی موجودگی میں محروم"
        elif father:
            it.excluded_reason = "باپ کی موجودگی میں محروم"
        else:
            gms.append(it)
    if c["mat_grandmother"]:
        it = add(_mk("mat_grandmother", 1))
        if c["mother"]:
            it.excluded_reason = "ماں کی موجودگی میں محروم"
        else:
            gms.append(it)
    if gms:
        _split_fixed(gms, F(1, 6))

    # father / grandfather
    for key, present in (("father", father), ("grandfather", c["grandfather"] > 0)):
        if not present:
            continue
        it = add(_mk(key, 1))
        if key == "grandfather" and father:
            it.excluded_reason = "باپ کی موجودگی میں محروم"
            continue
        if male_desc:
            it.fixed = F(1, 6)
        elif female_only_desc:
            it.fixed = F(1, 6)
            it.asaba, it.weight = True, 1
        else:
            it.asaba, it.weight = True, 1

    blocked_reason = ("نرینہ اولاد کی موجودگی میں محروم" if male_desc else
                      "باپ کی موجودگی میں محروم" if father else
                      "دادا کی موجودگی میں محروم" if gf else "")

    # uterine siblings
    if c["uterine"]:
        it = add(_mk("uterine", c["uterine"]))
        if any_desc:
            it.excluded_reason = "اولاد کی موجودگی میں محروم"
        elif blocked_reason:
            it.excluded_reason = blocked_reason
        else:
            it.fixed = F(1, 6) if c["uterine"] == 1 else F(1, 3)

    # full siblings
    fs_mode = None   # 'fixed', 'asaba', 'ghair'
    fs_fixed = F(0)
    fb = add(_mk("full_brother", c["full_brother"])) if c["full_brother"] else None
    fsi = add(_mk("full_sister", c["full_sister"])) if c["full_sister"] else None
    if fb or fsi:
        if blocked_reason:
            for it in (fb, fsi):
                if it:
                    it.excluded_reason = blocked_reason
        elif fb:
            fb.asaba, fb.weight = True, 2
            fs_mode = "asaba"
            if fsi:
                fsi.asaba, fsi.weight = True, 1
        else:
            if female_only_desc:
                fsi.asaba, fsi.weight = True, 1
                fs_mode = "ghair"
                res.notes.append("حقیقی بہن بیٹی/پوتی کے ساتھ عصبہ مع الغیر بنی")
            else:
                fs_fixed = F(1, 2) if c["full_sister"] == 1 else F(2, 3)
                fsi.fixed = fs_fixed
                fs_mode = "fixed"

    # paternal half siblings
    pb = add(_mk("pat_brother", c["pat_brother"])) if c["pat_brother"] else None
    ps = add(_mk("pat_sister", c["pat_sister"])) if c["pat_sister"] else None
    if pb or ps:
        reason = blocked_reason or ("حقیقی بھائی کی موجودگی میں محروم" if fb else
                                    "حقیقی بہن (عصبہ مع الغیر) کی موجودگی میں محروم" if fs_mode == "ghair" else "")
        if reason:
            for it in (pb, ps):
                if it:
                    it.excluded_reason = reason
        elif pb:
            pb.asaba, pb.weight = True, 2
            if ps:
                ps.asaba, ps.weight = True, 1
        else:
            if fs_fixed == F(2, 3):
                ps.excluded_reason = "دو حقیقی بہنوں نے 2/3 لے لیا"
            elif fs_fixed == F(1, 2):
                ps.fixed = F(1, 6)
            elif female_only_desc:
                ps.asaba, ps.weight = True, 1
            else:
                ps.fixed = F(1, 2) if c["pat_sister"] == 1 else F(2, 3)

    # only the highest-priority residuary group takes the residue
    order = [
        lambda i: i.key in ("son", "daughter", "son_son", "son_daughter", "sss", "ssd") or i.key.startswith("pre_"),
        lambda i: i.key in ("father", "grandfather"),
        lambda i: i.key in ("full_brother", "full_sister"),
        lambda i: i.key in ("pat_brother", "pat_sister"),
    ]
    asabas = [i for i in items if i.asaba and not i.excluded_reason]
    for pred in order:
        grp = [i for i in asabas if pred(i)]
        if grp:
            for i in asabas:
                if i not in grp:
                    i.asaba = False
                    if not i.fixed:
                        i.excluded_reason = "قریبی عصبہ کی موجودگی میں محروم"
            break

    _finish(items, res)
    _expand_lines(items)
    res.items = items
    return res


# ---------------------------------------------------------------------------
# Fiqh Jafaria
# ---------------------------------------------------------------------------
def _jafari(c, lines, law) -> Result:
    res = Result()
    items: List[Item] = []
    add = lambda it: (items.append(it), it)[1]

    spouse = None
    if c["husband"]:
        spouse = add(_mk("husband", 1))
    if c["wife"]:
        spouse = add(_mk("wife", c["wife"]))
        res.notes.append("فقہ جعفریہ: بیوہ کو زمین میں حصہ نہیں ملتا، صرف عمارت/منقولہ مال کی قیمت میں حصہ ملتا ہے (عدالتی رائے لیں)")

    # ---------- class 1: descendants + parents
    children_present = c["son"] + c["daughter"] > 0
    son_items, dau_items = [], []
    if c["son"]:
        son_items.append(add(_mk("son", c["son"])))
    if c["daughter"]:
        dau_items.append(add(_mk("daughter", c["daughter"])))

    # grandchildren by representation
    gc_items = []
    for key in ("son_son", "son_daughter", "sss", "ssd"):
        if c[key]:
            gc_items.append(add(_mk(key, c[key])))
    line_items = [add(_line_item(ln)) for ln in lines]

    if children_present:
        for it in gc_items:
            it.excluded_reason = "بیٹے/بیٹی کی موجودگی میں محروم"
        if law == "mflo":
            for it in line_items:
                (son_items if it.sex == "m" else dau_items).append(it)
            if line_items:
                res.notes.append("مسلم فیملی لاء آرڈیننس 1961 دفعہ 4: فوت شدہ بیٹے/بیٹی کی اولاد کو ان کے والدین کا حصہ دیا گیا")
        else:
            for it in line_items:
                it.excluded_reason = "اولاد کی موجودگی میں محروم"
    else:
        # representation: each predeceased child's line takes that child's share
        for it in line_items:
            (son_items if it.sex == "m" else dau_items).append(it)
        gs = [i for i in gc_items if i.key in ("son_son", "son_daughter")]
        ggs = [i for i in gc_items if i.key in ("sss", "ssd")]
        nearer = gs or line_items
        if gs:
            ln = {"kind": "son", "n": 0, "sons": c["son_son"], "daughters": c["son_daughter"]}
            v = Item(key="pota_line", count=1, sex="m", label_ur="پوتے/پوتیاں", label_en="Son's children", line=ln)
            for i in gs:
                i.excluded_reason = "__merged__"
            son_items.append(add(v))
        if ggs:
            if nearer:
                for i in ggs:
                    i.excluded_reason = "قریبی پوتا/پوتی کی موجودگی میں محروم"
            else:
                ln = {"kind": "son", "n": 0, "sons": c["sss"], "daughters": c["ssd"]}
                v = Item(key="parpota_line", count=1, sex="m", label_ur="پڑپوتے/پڑپوتیاں", label_en="Great-grandchildren", line=ln)
                for i in ggs:
                    i.excluded_reason = "__merged__"
                son_items.append(add(v))

    any_desc = bool(son_items or dau_items)
    father = c["father"] > 0
    mother = c["mother"] > 0
    class1 = any_desc or father or mother

    if spouse is not None:
        if spouse.key == "husband":
            spouse.fixed = F(1, 4) if any_desc else F(1, 2)
        else:
            spouse.fixed = F(1, 8) if any_desc else F(1, 4)

    if class1:
        for key in ("pat_grandmother", "mat_grandmother", "grandfather", "full_brother", "full_sister",
                    "uterine", "pat_brother", "pat_sister"):
            if c[key]:
                add(_mk(key, c[key])).excluded_reason = "پہلے درجہ (والدین/اولاد) کی موجودگی میں محروم"

        b = c["full_brother"] + c["pat_brother"]
        s = c["full_sister"] + c["pat_sister"]
        hajib = father and (b >= 2 or (b == 1 and s >= 2) or s >= 4)
        f_it = add(_mk("father", 1)) if father else None
        m_it = add(_mk("mother", 1)) if mother else None
        if m_it:
            m_it.fixed = F(1, 6) if (any_desc or hajib) else F(1, 3)
            if hajib and not any_desc:
                res.notes.append("بھائیوں کی موجودگی (حاجب) کی وجہ سے ماں کا حصہ 1/6")
        has_son = bool(son_items)
        if f_it:
            if any_desc:
                f_it.fixed = F(1, 6)
            else:
                f_it.asaba, f_it.weight = True, 1
        if has_son:
            for it in son_items:
                it.asaba, it.weight = True, 2
            for it in dau_items:
                it.asaba, it.weight = True, 1
            if f_it:
                f_it.asaba = False
        elif dau_items:
            heads = sum(i.count for i in dau_items)
            _split_fixed(dau_items, F(1, 2) if heads == 1 else F(2, 3))
        radd_only = [i.key for i in items if i.key in ("father", "daughter") or i.key.startswith("pre_daughter")]
        if m_it and not hajib:
            radd_only.append("mother")
        if not radd_only and m_it:
            radd_only.append("mother")
        _finish(items, res, radd_only=radd_only, jafari=True,
                deficit_keys=[i.key for i in dau_items])
    else:
        # ---------- class 2: grandparents + siblings
        full_present = c["full_brother"] + c["full_sister"] > 0
        bro_key, sis_key = ("full_brother", "full_sister") if full_present else ("pat_brother", "pat_sister")
        if full_present:
            for key in ("pat_brother", "pat_sister"):
                if c[key]:
                    add(_mk(key, c[key])).excluded_reason = "حقیقی بہن بھائی کی موجودگی میں محروم"
        pat_m = []
        pat_f = []
        if c[bro_key]:
            pat_m.append(add(_mk(bro_key, c[bro_key])))
        if c["grandfather"]:
            pat_m.append(add(_mk("grandfather", 1)))
        if c[sis_key]:
            pat_f.append(add(_mk(sis_key, c[sis_key])))
        if c["pat_grandmother"]:
            pat_f.append(add(_mk("pat_grandmother", 1)))
        mat = []
        if c["uterine"]:
            mat.append(add(_mk("uterine", c["uterine"])))
        if c["mat_grandmother"]:
            mat.append(add(_mk("mat_grandmother", 1)))

        if mat:
            n = sum(i.count for i in mat)
            only_sib = all(i.key == "uterine" for i in mat)
            _split_fixed(mat, F(1, 6) if (n == 1 and only_sib) else F(1, 3))
        if pat_m:
            for it in pat_m:
                it.asaba, it.weight = True, 2
            for it in pat_f:
                it.asaba, it.weight = True, 1
        elif pat_f:
            heads = sum(i.count for i in pat_f)
            _split_fixed(pat_f, F(1, 2) if heads == 1 else F(2, 3))
        radd_only = [i.key for i in pat_f] if pat_f else [i.key for i in mat]
        _finish(items, res, radd_only=radd_only, jafari=True,
                deficit_keys=[i.key for i in pat_f])

    items = [i for i in items if i.excluded_reason != "__merged__"]
    _expand_lines(items)
    res.items = items
    return res


# ---------------------------------------------------------------------------
# split a predeceased child's line between its own sons/daughters (2:1)
# ---------------------------------------------------------------------------
def _expand_lines(items: List[Item]):
    for it in items:
        ln = it.line
        if not ln:
            continue
        parts = []
        w = ln["sons"] * 2 + ln["daughters"]
        if it.key == "pota_line":
            names = (("son_son", "پوتا", "Grandson"), ("son_daughter", "پوتی", "Granddaughter"))
        elif it.key == "parpota_line":
            names = (("sss", "پڑپوتا", "Great-grandson"), ("ssd", "پڑپوتی", "Great-granddaughter"))
        elif ln["kind"] == "son":
            names = ((f"{it.key}_sons", f"پوتا (فوت شدہ بیٹا {ln['n']})", f"Grandson (predeceased son {ln['n']})"),
                     (f"{it.key}_daughters", f"پوتی (فوت شدہ بیٹا {ln['n']})", f"Granddaughter (predeceased son {ln['n']})"))
        else:
            names = ((f"{it.key}_sons", f"نواسہ (فوت شدہ بیٹی {ln['n']})", f"Grandson (predeceased daughter {ln['n']})"),
                     (f"{it.key}_daughters", f"نواسی (فوت شدہ بیٹی {ln['n']})", f"Granddaughter (predeceased daughter {ln['n']})"))
        for (key, ur, en), n, wt in ((names[0], ln["sons"], 2), (names[1], ln["daughters"], 1)):
            if n:
                parts.append({"key": key, "label_ur": ur, "label_en": en, "count": n,
                              "share": it.share * n * wt / w if w else F(0)})
        it.line = dict(ln, parts=parts)


# ---------------------------------------------------------------------------
# Presentation: flatten, common denominator, land & money
# ---------------------------------------------------------------------------
def _fmt(fr: F) -> str:
    return f"{fr.numerator}/{fr.denominator}" if fr.denominator != 1 else str(fr.numerator)


def divide_area(share: F, total_marla: F, unit: str):
    upm = UNITS_PER_MARLA[unit]
    m = share * total_marla
    kanal = int(m // 20)
    rem = m - kanal * 20
    marla = int(rem // 1)
    sub = round(float((rem - marla) * upm), 2)
    if sub >= upm:
        sub -= upm
        marla += 1
        if marla >= 20:
            marla -= 20
            kanal += 1
    return {"kanal": kanal, "marla": marla, "sub": sub, "total_marla": round(float(m), 4)}


def build_report(res: Result, area: Optional[dict] = None, amount=None) -> dict:
    rows = []
    for it in res.items:
        base = {"key": it.key, "label_ur": it.label_ur, "label_en": it.label_en, "count": it.count}
        if it.excluded_reason and not it.share:
            rows.append(dict(base, excluded=True, reason=it.excluded_reason))
            continue
        if it.line and it.line.get("parts"):
            for p in it.line["parts"]:
                rows.append({"key": p["key"], "label_ur": p["label_ur"], "label_en": p["label_en"],
                             "count": p["count"], "group_share": p["share"], "excluded": False})
        else:
            rows.append(dict(base, group_share=it.share, excluded=False))

    live = [r for r in rows if not r["excluded"] and r["group_share"]]
    for r in rows:
        if r["excluded"]:
            continue
        r["each_share"] = r["group_share"] / r["count"]
    base_den = 1
    for r in live:
        base_den = lcm(base_den, r["each_share"].denominator)

    total_marla = None
    unit = "foot"
    if area:
        unit = (area.get("unit") or "foot").lower()
        if unit not in UNITS_PER_MARLA:
            raise InputError("unit must be foot, sarsai or yard")
        k = F(str(area.get("kanal") or 0))
        mr = F(str(area.get("marla") or 0))
        sb = F(str(area.get("sub") or 0))
        if k < 0 or mr < 0 or sb < 0:
            raise InputError("area cannot be negative")
        total_marla = k * 20 + mr + sb / UNITS_PER_MARLA[unit]
        if total_marla == 0:
            total_marla = None
    amt = None
    if amount not in (None, ""):
        try:
            amt = F(str(amount))
        except Exception:
            raise InputError("amount must be a number")
        if amt < 0:
            raise InputError("amount cannot be negative")

    out_rows = []
    for r in rows:
        o = {k: v for k, v in r.items() if k not in ("group_share", "each_share")}
        if not r["excluded"]:
            gs, es = r["group_share"], r["each_share"]
            o.update({
                "group_share": _fmt(gs), "each_share": _fmt(es),
                "group_percent": round(float(gs) * 100, 4), "each_percent": round(float(es) * 100, 4),
                "group_hisay": int(gs * base_den), "each_hisay": int(es * base_den),
            })
            if total_marla is not None:
                o["group_area"] = divide_area(gs, total_marla, unit)
                o["each_area"] = divide_area(es, total_marla, unit)
            if amt is not None:
                o["group_amount"] = round(float(gs * amt), 2)
                o["each_amount"] = round(float(es * amt), 2)
        out_rows.append(o)

    status_ur = {"awl": "عمل عول", "radd": "عمل رد", "equal": "ترکہ برابر تقسیم ہو گیا"}[res.status]
    rep = {
        "status": res.status, "status_ur": status_ur, "notes": res.notes,
        "total_hisay": base_den, "rows": out_rows,
        "unallocated": _fmt(res.unallocated) if res.unallocated else None,
        "unit": unit, "unit_ur": UNIT_UR[unit],
    }
    if total_marla is not None:
        rep["total_area"] = divide_area(F(1), total_marla, unit)
    if amt is not None:
        rep["amount"] = float(amt)
    return rep


def run(payload: dict) -> dict:
    """Convenience: JSON payload in, JSON-able report out."""
    res = calculate(payload.get("heirs") or {}, payload.get("fiqh", "hanafi"), payload.get("law", "mflo"),
                    payload.get("predeceased_sons"), payload.get("predeceased_daughters"))
    return build_report(res, payload.get("area"), payload.get("amount"))
