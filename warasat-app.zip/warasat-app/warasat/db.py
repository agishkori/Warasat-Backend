import sqlite3
from datetime import datetime, timedelta, timezone

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    trial_ends TEXT NOT NULL,
    paid_until TEXT,
    is_admin INTEGER NOT NULL DEFAULT 0,
    is_blocked INTEGER NOT NULL DEFAULT 0,
    device_id TEXT
);
CREATE TABLE IF NOT EXISTS tokens (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    method TEXT NOT NULL,
    txn_id TEXT NOT NULL UNIQUE,
    sender_number TEXT,
    amount INTEGER NOT NULL,
    months INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'pending',
    note TEXT,
    created_at TEXT NOT NULL,
    reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS calculations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    title TEXT,
    input_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS play_purchases (
    purchase_token TEXT PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    product_id TEXT,
    plan TEXT,
    state TEXT,
    expiry TEXT,
    auto_renewing INTEGER DEFAULT 0,
    acknowledged INTEGER DEFAULT 0,
    order_id TEXT,
    linked_token TEXT,
    is_test INTEGER DEFAULT 0,
    raw TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_play_user ON play_purchases(user_id);
CREATE INDEX IF NOT EXISTS idx_pay_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_calc_user ON calculations(user_id);
"""

FMT = "%Y-%m-%d %H:%M:%S"


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def ts(dt):
    return dt.strftime(FMT) if dt else None


def parse(s):
    return datetime.strptime(s, FMT) if s else None


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    with app.app_context():
        db = sqlite3.connect(app.config["DATABASE"])
        db.executescript(SCHEMA)
        cols = [r[1] for r in db.execute("PRAGMA table_info(users)")]
        if "play_until" not in cols:
            db.execute("ALTER TABLE users ADD COLUMN play_until TEXT")
        db.commit()
        db.close()
    app.teardown_appcontext(close_db)


# ---------------------------------------------------------------- subscription
def subscription(user):
    """Return dict describing whether the user may use the calculator."""
    n = now()
    trial_ends = parse(user["trial_ends"])
    paid_until = max([d for d in (parse(user["paid_until"]), parse(user["play_until"])) if d] or [None])
    active_until = max([d for d in (trial_ends, paid_until) if d] or [n])
    active = (active_until > n and not user["is_blocked"]) or bool(user["is_admin"])
    on_trial = trial_ends > n and not (paid_until and paid_until > n)
    days_left = max(0, (active_until - n).days + (1 if (active_until - n).seconds > 0 else 0)) if active_until > n else 0
    return {
        "active": active,
        "on_trial": on_trial,
        "trial_ends": ts(trial_ends),
        "paid_until": ts(paid_until),
        "active_until": ts(active_until),
        "days_left": days_left,
    }


def extend_subscription(db, user_id, days):
    """Manual extension by admin (adds days after the current end date)."""
    u = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    start = max(d for d in (now(), parse(u["trial_ends"]), parse(u["paid_until"]), parse(u["play_until"])) if d)
    new_until = start + timedelta(days=days)
    db.execute("UPDATE users SET paid_until=? WHERE id=?", (ts(new_until), user_id))
    return new_until
